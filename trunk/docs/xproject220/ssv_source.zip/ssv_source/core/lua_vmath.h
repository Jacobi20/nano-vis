

#pragma once

CORE_API    void    LuaOpenVMath    ( lua_State *L );
CORE_API    void    LuaCloseVMath    ( lua_State *L );

CORE_API    void    LuaPushVec4        ( lua_State *L, const EVec4 &v );
CORE_API    bool    LuaIsVec4        ( lua_State *L, int idx );
CORE_API    EVec4    LuaToVec4        ( lua_State *L, int idx );
CORE_API    EVec4    LuaRequireVec4    ( lua_State *L, int idx, const char *what );

CORE_API    void    LuaPushQuat        ( lua_State *L, const EQuat &v );
CORE_API    bool    LuaIsQuat        ( lua_State *L, int idx );
CORE_API    EQuat    LuaToQuat        ( lua_State *L, int idx );
CORE_API    EQuat    LuaRequireQuat    ( lua_State *L, int idx, const char *what );

inline EVec4 LuaRequireFieldVec4( lua_State *L, int table_index, const char *field )
{
    lua_getfield(L, table_index, field);
    if (!LuaIsVec4(L, -1)) {
        lua_pop(L, 1);
        LuaArgumentError(L, table_index, "table[] vec4", field);
        return 0;
    } else {
        EVec4 value = LuaToVec4(L, -1);
        lua_pop(L, 1);
        return value;
    }
}

