

#pragma once

#include "../core/core.h"
#include "core_linker.h"
