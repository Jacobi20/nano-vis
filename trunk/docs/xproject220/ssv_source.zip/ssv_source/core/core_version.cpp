

#include "../core/core.h"

#define PROJECT_NAME    "Eclipse Engine"
#define VERSION            "2.00"

#ifdef _DEBUG
#define BUILD_CONFIG    "debug"
#else
#define BUILD_CONFIG    "release"
#endif

#define BUILD_DATE        __DATE__
#define SVN_REVISION     "2197"
#define SVN_DATE         "2010/05/18 17:42:39"

#define PLATFORM_NAME    "win-x86"

DLL_EXPORT const char *Version(void)
{
    const char *version = PROJECT_NAME" "VERSION"."SVN_REVISION" "PLATFORM_NAME" "BUILD_CONFIG" "BUILD_DATE;
    return version;
}

