

#ifndef _zip_H
#define _zip_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _ZLIB_H
#include "zlib.h"
#endif

#ifndef _ZLIBIOAPI_H
#include "ioapi.h"
#endif

#if defined(STRICTZIP) || defined(STRICTZIPUNZIP)

typedef struct TagzipFile__ { int unused; } zipFile__;
typedef zipFile__ *zipFile;
#else
typedef voidp zipFile;
#endif

#define ZIP_OK                                  (0)
#define ZIP_ERRNO               (Z_ERRNO)
#define ZIP_PARAMERROR                  (-102)
#define ZIP_INTERNALERROR               (-104)

typedef struct tm_zip_s
{
    uInt tm_sec;
    uInt tm_min;
    uInt tm_hour;
    uInt tm_mday;
    uInt tm_mon;
    uInt tm_year;
} tm_zip;

typedef struct
{
    tm_zip      tmz_date;
    uLong       dosDate;

    uLong       internal_fa;
    uLong       external_fa;
} zip_fileinfo;

typedef const char* zipcharpc;

extern zipFile ZEXPORT zipOpen OF((const char *pathname, int append));

extern zipFile ZEXPORT zipOpen2 OF((const char *pathname,
                                   int append,
                                   zipcharpc* globalcomment,
                                   zlib_filefunc_def* pzlib_filefunc_def));

extern int ZEXPORT zipOpenNewFileInZip OF((zipFile file,
                       const char* filename,
                       const zip_fileinfo* zipfi,
                       const void* extrafield_local,
                       uInt size_extrafield_local,
                       const void* extrafield_global,
                       uInt size_extrafield_global,
                       const char* comment,
                       int method,
                       int level));

extern int ZEXPORT zipOpenNewFileInZip2 OF((zipFile file,
                       const char* filename,
                       const zip_fileinfo* zipfi,
                       const void* extrafield_local,
                       uInt size_extrafield_local,
                       const void* extrafield_global,
                       uInt size_extrafield_global,
                       const char* comment,
                       int method,
                       int level,
                       int raw));

extern int ZEXPORT zipWriteInFileInZip OF((zipFile file,
                       const voidp buf,
                       unsigned len));

extern int ZEXPORT zipCloseFileInZip OF((zipFile file));

extern int ZEXPORT zipCloseFileInZipRaw OF((zipFile file,
                                            uLong uncompressed_size,
                                            uLong crc32));

extern int ZEXPORT zipClose OF((zipFile file,
                const char* global_comment));

#ifdef __cplusplus
}
#endif

#endif
