

#include "../core/core.h"
#include "config.h"

EVar::EVar( const char *name, uint flags )
{
   this->name    =    name;
   this->flags    =    flags;

   L    =    Linker()->GetShell()->Lua();
   lua_pushnil(L);
   lua_setfield(L, LUA_GLOBALSINDEX, name);
}

EVar::~EVar( void )
{
}

void EVar::Set( bool value )
{
    lua_pushboolean(L, value);
    lua_setglobal(L, name.Name());
}

void EVar::Set( int value )
{
    lua_pushnumber(L, (double)value);
    lua_setglobal(L, name.Name());
}

void EVar::Set( float value )
{
    lua_pushnumber(L, (double)value);
    lua_setglobal(L, name.Name());
}

void EVar::Set( const char *value )
{
    lua_pushstring(L, value);
    lua_setglobal(L, name.Name());
}

bool EVar::Nil( void ) const
{
    lua_getglobal(L, name.Name());
    bool result = lua_isnil(L, -1);
    lua_pop(L, 1);
    return result;
}

bool EVar::Bool( void ) const
{
    lua_getglobal(L, name.Name());
    bool result = (lua_toboolean(L, -1)!=0);
    lua_pop(L, 1);
    return result;
}

int EVar::Int( void ) const
{
    lua_getglobal(L, name.Name());
    int result = lua_tonumber(L, -1);
    lua_pop(L, 1);
    return result;
}

float EVar::Float( void ) const
{
    lua_getglobal(L, name.Name());
    float result = lua_tonumber(L, -1);
    lua_pop(L, 1);
    return result;
}

const char * EVar::String( void ) const
{
    lua_getglobal(L, name.Name());

    const char *s = lua_tostring(L, -1);
    if (s) {
        strval    =    s;
    } else {
        strval    =    "";
    }
    lua_pop(L, 1);
    return strval.c_str();
}
