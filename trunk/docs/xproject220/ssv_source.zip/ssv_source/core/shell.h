

#pragma once

//        virtual uint        Flags            ( void ) const { return 0; }

class    EShell : public IShell {
    public:
                            EShell                    ( void );
                            ~EShell                    ( void );

        virtual void        AddCommand                ( const char *name, EShellCmd_f cmd_func, void *self );
        virtual void        RemoveCommand            ( const char *name );
        virtual void        DefineCFunc                ( const char *name, ELuaCFunc_f lua_cfunc );

        virtual void        ExecuteString            ( const char *cmd_text,  bool raise_error );
        virtual void        ExecuteScript            ( const char *file_name, bool raise_error );

        virtual const char    *CompleteCommand        ( const char *text );

        virtual lua_State    *Lua                    ( void ) { return L; }

        virtual int            LuaWarning                ( const char *text );
        virtual int            LuaError                ( const char *text );

    private:
        lua_State    *L;

        void                InitShellLib    ( void );

        static int            AtPanic            ( lua_State *L );
        static int            Print            ( lua_State *L );
        static int            CmdWrapper        ( lua_State *L );

        vector<EName>        cmd_names;
    };

