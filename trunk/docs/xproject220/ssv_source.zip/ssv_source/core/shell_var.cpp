

#include "../core/core.h"
#include "shell.h"

#if 0

EVar::EVar( EShell *shell, const char *name, const char *value )
{
    this->shell = shell;
    this->L        = shell->Lua();
    this->name    = name;

    ASSERT(name);
    ASSERT(value);

    lua_getfield(L, LUA_GLOBALSINDEX, name);

    if (lua_isnil(L, -1)) {
        lua_pop(L, 1);

        lua_pushstring(L, value);
        lua_setfield(L, LUA_GLOBALSINDEX, name);
    } else {
        lua_pop(L, 1);
    }
}

EVar::~EVar( void )
{

}

void EVar::SetValue( const char *val )
{
    lua_pushstring(L, val);
    lua_setfield(L, LUA_GLOBALSINDEX, name.Name());
}

const char    * EVar::String( void ) const
{
    lua_getfield(L, LUA_GLOBALSINDEX, name.Name());

    if (const char *s = lua_tostring(L, -1)) {
        value    =    s;
    } else {
        value    =    "";
    }

    lua_pop(L, -1);

    return value.c_str();
}

#endif
