

#pragma once

struct EApi_t {
        IPxDLL    dll_shell;    IPxShell            shell;
        IPxDLL    dll_cfg;    IPxConfig            cfg;
        IPxDLL    dll_fs;        IPxFileSystem        fs;
        IPxDLL    dll_ns;        IPxNetworkSystem    ns;
        IPxDLL    dll_rs;        IPxRenderSystem        rs;
        IPxDLL    dll_ss;        IPxSoundSystem        ss;
        IPxDLL    dll_is;        IPxInputSystem        is;
        IPxDLL    dll_game;    IPxGame                game;
        IPxDLL    dll_ui;        IPxUserInterface    ui;
        IPxDLL    dll_ge;        IPxGeometryEngine    ge;
        IPxDLL    dll_pe;        IPxPhysEngine        pe;
        IPxDLL    dll_nvis;    IPxNanoVis            nvis;
    };

class ELinker : public ILinker {
    public:
                                    ELinker                ( void );
        virtual                        ~ELinker            ( void );

        virtual    IPxShell            GetShell            ( void );
        virtual    IPxConfig            GetConfig            ( void );
        virtual    IPxFileSystem        GetFileSystem        ( void );
        virtual IPxNetworkSystem    GetNetworkSystem    ( void );
        virtual    IPxRenderSystem     GetRenderSystem        ( void );
        virtual    IPxSoundSystem        GetSoundSystem        ( void );
        virtual IPxInputSystem        GetInputSystem        ( void );
        virtual    IPxGame                GetGame                ( void );
        virtual IPxUserInterface     GetUserInterface    ( void );
        virtual IPxGeometryEngine    GetGeometryEngine    ( void );
        virtual IPxPhysEngine        GetPhysEngine        ( void );
        virtual IPxNanoVis            GetNanoVis            ( void );

        virtual void                LinkShell            ( IShell *shell );
        virtual void                LinkConfig            ( IConfig *cfg );
        virtual void                LinkFileSystem        ( IFileSystem *fs );
        virtual void                LinkNetworkSystem    ( INetworkSystem *ns );
        virtual void                LinkRenderSystem    ( IRenderSystem *rs );
        virtual void                LinkSoundSystem        ( ISoundSystem *ss );
        virtual void                LinkInputSystem        ( IInputSystem *is );
        virtual void                LinkGame            ( IGame    *game );
        virtual void                LinkUserInterface    ( IUserInterface *ui );
        virtual void                LinkGeometryEngine    ( IGeometryEngine *ge );
        virtual void                LinkPhysEngine        ( IPhysEngine *pe );
        virtual void                LinkNanoVis            ( INanoVis *nvis );

        virtual void                LinkDLLShell            ( const char *dllname );
        virtual void                LinkDLLConfig            ( const char *dllname );
        virtual void                LinkDLLFileSystem        ( const char *dllname );
        virtual void                LinkDLLNetworkSystem    ( const char *dllname );
        virtual void                LinkDLLRenderSystem        ( const char *dllname );
        virtual void                LinkDLLSoundSystem        ( const char *dllname );
        virtual void                LinkDLLInputSystem        ( const char *dllname );
        virtual void                LinkDLLGame                ( const char *dllname );
        virtual void                LinkDLLUserInterface    ( const char *dllname );
        virtual void                LinkDLLGeometryEngine    ( const char *dllname );
        virtual void                LinkDLLPhysEngine        ( const char *dllname );
        virtual void                LinkDLLNanoVis            ( const char *dllname );

    protected:
        EApi_t    api;
    };

