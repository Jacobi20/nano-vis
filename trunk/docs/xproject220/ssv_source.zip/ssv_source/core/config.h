

#pragma once

class EVar : public IVar {
    public:
                            EVar    ( const char *name, uint flags );
                            ~EVar    ( void );

        virtual void        Set        ( bool value );
        virtual void        Set        ( int value );
        virtual void        Set        ( float value );
        virtual void        Set        ( const char *value );

        virtual bool        Nil        ( void ) const;
        virtual bool        Bool    ( void ) const;
        virtual int            Int        ( void ) const;
        virtual float        Float    ( void ) const;
        virtual const char *String    ( void ) const;

        virtual EName        Name    ( void ) const { return name; }
        virtual uint        Flags    ( void ) const { return flags; }

    protected:
        EName    name;
        uint    flags;
        lua_State    *L;
        mutable string strval;
    };

class EConfig : public IConfig {
    public:
                            EConfig            ( void );
                            ~EConfig        ( void );

        virtual void        SetUser            ( const char *username );
        virtual const char    *GetUser        ( void ) const;
        virtual IPxVar        RegisterVar        ( const char *name, uint flag );
        virtual void        LoadConfig        ( void );
        virtual void        SaveConfig        ( void );
    protected:
        lua_State    *L;

        static int            RegVar            ( lua_State *L );
        static int            SetVar            ( lua_State *L );
        static int            SaveConfig        ( lua_State *L );
        static int            LoadConfig        ( lua_State *L );

        vector<IPxVar>    vars;
    };

