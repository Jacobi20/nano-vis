

#include "../core/core.h"
#include "shell.h"

int EShell::LuaWarning( const char *text )
{
    luaL_where(L, 1);

    LOG_WARNING("%s: %s", lua_tostring(L, -1), text);

    lua_pop(L, 1);

    return 0;
}

int EShell::LuaError( const char *text )
{
    lua_Debug ar;

    string func_name;

    if (lua_getstack(L, 0, &ar)) {
        lua_getinfo(L, "nSlu", &ar);
        if (ar.name) {
            func_name = ar.name;
            func_name += "()";
        }
    }

    if (lua_getstack(L, 1, &ar)) {
        lua_getinfo(L, "nSlu", &ar);
        lua_pushstring(L, va("%s:%d: %s: %s", ar.short_src, ar.currentline, func_name.c_str(), text));
    } else {
        lua_pushstring(L, text);
    }
    return lua_error(L);
}

