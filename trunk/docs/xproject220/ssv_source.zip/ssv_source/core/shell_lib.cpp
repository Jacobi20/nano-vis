

#include "../core/core.h"
#include "shell.h"

static int tmerge(lua_State *L)
{
    lua_newtable(L);

    if (!lua_istable(L, 1)) {
        return 1;
    }

    lua_pushnil(L);
    while (lua_next(L, 1)!=0) {
        lua_pushvalue(L, -2);
        lua_pushvalue(L, -2);
        lua_settable(L, -5);
        lua_pop(L, 1);
    }

    if (!lua_istable(L, 2)) {
        return 1;
    }

    lua_pushnil(L);
    while (lua_next(L, 2)!=0) {
        lua_pushvalue(L, -2);
        lua_pushvalue(L, -2);
        lua_settable(L, -5);
        lua_pop(L, 1);
    }

    return 1;
}

static const luaL_Reg tfuncs[] = {
  {"merge",        tmerge},
  {NULL,        NULL}
};

void EShell::InitShellLib( void )
{
    luaL_register(L, LUA_TABLIBNAME, tfuncs);
}

