

#pragma once

#pragma warning (disable : 4800)
#pragma warning (disable : 4996)
#pragma warning (disable : 4244)
#pragma warning (disable : 4251)    //    'identifier' : class 'type' needs to have dll-interface to be used by clients of class 'type2'

#ifdef WIN32
    #ifndef _CPPRTTI
        #error  Run-time type information is disabled!
    #endif

    #ifndef _CPPUNWIND
        #error  Exception handling is disabled!
    #endif
#endif

#undef DLL_EXPORT
#undef DLL_IMPOR
#ifdef _WIN32
    #define DLL_EXPORT  extern "C"  __declspec(dllexport)
    #define DLL_IMPORT  extern "C"  __declspec(dllimport)
#else
    #define DLL_EXPORT
    #define DLL_IMPORT
#endif

#ifdef STATIC_CORE
    #define CORE_API
#else
    #ifdef CORE_EXPORTS
        #define CORE_API  __declspec(dllexport)
    #else
        #define CORE_API  __declspec(dllimport)
    #endif
#endif

#ifdef WIN32
    #define WIN32_LEAN_AND_MEAN
    #define VC_EXTRALEAN
    #include <windows.h>

    #ifdef _DEBUG
    #define _CRTDBG_MAP_ALLOC
    #include <stdlib.h>
    #include <crtdbg.h>
    #endif

    #define OS_MAX_PATH MAX_PATH

    #include "win_key_list.h"
#endif

#include "../core/library/library.h"

#include "../core/rapidxml/rapidxml.hpp"
#include "../core/rapidxml/rapidxml_ext.hpp"
using namespace rapidxml;

extern "C" {
    #include "../core/lua/src/lua.h"
    #include "../core/lua/src/lualib.h"
    #include "../core/lua/src/lauxlib.h"
}

#ifndef NO_CORE_INTERFACES
#include "../core/interfaces/interfaces.h"
#endif

#define LOGF(frmt, ...)            Log()->LogMessage(LOG_MSG_INFO,        __FILE__,__LINE__, frmt, __VA_ARGS__)
#define LOG_WARNING(frmt, ...)    Log()->LogMessage(LOG_MSG_WARNING,    __FILE__,__LINE__, frmt, __VA_ARGS__)
#define LOG_ERROR(frmt, ...)    Log()->LogMessage(LOG_MSG_ERROR,    __FILE__,__LINE__, frmt, __VA_ARGS__)
#define LOG_FATAL(frmt, ...)    Log()->LogMessage(LOG_MSG_FATAL,    __FILE__,__LINE__, frmt, __VA_ARGS__)
#define LOG_DEBUG(frmt, ...)    Log()->LogMessage(LOG_MSG_DEBUG,    __FILE__,__LINE__, frmt, __VA_ARGS__)
#define LOG_DIM(frmt, ...)        Log()->LogMessage(LOG_MSG_DIMMED,    __FILE__,__LINE__, frmt, __VA_ARGS__)

#define LOG_INIT(s)                Log()->LogMessage(LOG_MSG_INFO,        __FILE__,__LINE__, "INIT : %s", s)
#define LOG_SHUTDOWN(s)            Log()->LogMessage(LOG_MSG_INFO,        __FILE__,__LINE__, "SHUTDOWN : %s", s)
#define LOG_SPLIT(headline)        Log()->LogSplit(headline);

#define DEBUG_STRING(frmt, ...)    Log()->AddDebugString(frmt, __VA_ARGS__)

#include "../core/lua_ext.h"
#include "../core/lua_vmath.h"

