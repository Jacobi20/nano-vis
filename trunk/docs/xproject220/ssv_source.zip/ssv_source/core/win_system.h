

#pragma once

class    EWinDLL : public IDLL {
    public:
                                EWinDLL            ( const char *dll_name );
        virtual                    ~EWinDLL        ( void );
        virtual    void*            GetProcAddr        ( const char *func_name );
    protected:
        HMODULE    h_dll;
        string    name;
    };

class    EWinSystem : public ISystem
    {
    public:
                                EWinSystem        ( void );
        virtual                    ~EWinSystem        ( void );

        virtual const char        *GetCmdLine        ( void );

        virtual    uint            Milliseconds    ( void );
        virtual    systemTime_t    GetGMTTime        ( void );
        virtual    systemTime_t    GetLocalTime    ( void );

        virtual    void            Quit            ( uint code );
        virtual void            Terminate        ( uint code );

        virtual IPxDLL            LoadDLL            ( const char *dll_name );

        virtual thread_t        SpawnThread        ( threadFunc_f func, void *param );
        virtual void            KillThread        ( thread_t thread );
        virtual void            Sleep            ( uint msec );

        virtual double            MSecRDTSC        ( void );

    protected:
        uint64_t                RDTSC            ( void );
        void                    CheckCPUClock    ( void );

        uint        init_msec;
        uint64_t    init_tick;
        uint64_t    ticks_per_second;
    };
