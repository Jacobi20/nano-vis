

#include "core_local.h"

#include <crtdbg.h>

#define USE_LOG_FILE

struct ELogLine_s {
        ELogMsgType_t    msg_type;
        char            message[LOG_LINE_LEN];
        const char    *    src_file;
        uint            src_line;
        uint            result;
    };

const uint LOG_MAX_DEBUG_STRINGS = 256;

struct ELogDbgString_s {
        char    message[LOG_LINE_LEN];
    };

class ELog : public ILog {
    public:
                            ELog            ( void );
                            ~ELog            ( void );

        virtual    uint        LogMessage            ( ELogMsgType_t msg_type, const char *src_file, uint src_line, const char *frmt, ... );

        virtual void        SetWriteCB            ( ELogWriteCB_f write_cb, void *self );
        virtual void        GetLogMessage        ( uint line, ELogMessage_s &message ) const;
        virtual void        GetLogLastMessage    ( ELogMessage_s &message ) const;
        virtual uint        GetLogMessageNum    ( void ) const;
        virtual void        Clear                ( void );
        virtual void        LogSplit            ( const char *headline, char fill_char );

        virtual void        AddDebugString        ( const char *frmt, ... );
        virtual void        ClearDebugStrings    ( void );
        virtual const char    *GetDebugString        ( uint index ) const;
        virtual uint        GetDebugStringNum    ( void ) const;

    protected:
        ELogWriteCB_f    write_cb;
        void            *write_cb_self;

        uint            debug_strings_num;
        ELogDbgString_s    debug_strings[LOG_MAX_DEBUG_STRINGS];

        ELogLine_s    log_lines[LOG_MAX_LINES];
        uint        current_line;
        uint        total_lines;

        FILE        *log_file;
    };

ELog log_static_imp;

ILog *Log(void)
{
    return &log_static_imp;
}

void DecolorizeString(const char *input, char *output)
{
    for ( ; *input; *input++, *output++ ) {
        if (*input=='^') {
            input++;
            if (*input>='0' && *input<='9') {
                input++;
            }
        }
        *output = *input;
    }
    *output = '\0';
}

ELog::ELog(void)
{
    SetWriteCB(NULL, NULL);
    Clear();

    log_file    =    NULL;
#ifdef USE_LOG_FILE
    log_file    =    fopen("engine.log", "a");
    if (log_file) {
        fputs("\r\n-------------------------------------------------------------------------------\r\n", log_file);
    }
#endif
}

ELog::~ELog(void)
{
    if (log_file) {
        fclose(log_file);
    }
}

void ELog::Clear(void)
{
    memset(log_lines,    0, sizeof(log_lines));
    current_line = 0;
    total_lines = 0;
}

uint ELog::LogMessage( ELogMsgType_t msg_type, const char *src_file, uint src_line, const char *frmt, ... )
{
    uint msg_id = 0;

    char message[512];
    va_list    argptr;
    va_start (argptr, frmt);
    vsnprintf (message, 512-1, frmt, argptr);
    va_end (argptr);

    uint len = strlen(message);
    for (uint i=0; i<len; i++) {
        switch (message[i]) {
            case '\r' :
            case '\n' :
                message[i] = '\0';
        }
    }

    memset( log_lines[ current_line ].message, 0, LOG_LINE_LEN );
    memcpy( log_lines[ current_line ].message, message, min(strlen(message), LOG_LINE_LEN-1) );
    log_lines[ current_line ].msg_type    =    msg_type;
    log_lines[ current_line ].src_file    =    src_file;
    log_lines[ current_line ].src_line    =    src_line;

    msg_id = current_line;

    current_line++;
    current_line %= LOG_MAX_LINES;
    total_lines++;

    if (write_cb) {
        write_cb( write_cb_self );
    }

    systemTime_t t = System()->GetLocalTime();
    uint h  = t.hour;
    uint m  = t.minute;
    uint s  = t.sec;
    uint ms = t.msec;

    #ifdef USE_LOG_FILE

        const char *prefix    =    NULL;
        if (msg_type==LOG_MSG_ERROR)    prefix    =    "[ ERROR ] "; else
        if (msg_type==LOG_MSG_WARNING)    prefix    =    "[WARNING] "; else
        if (msg_type==LOG_MSG_FATAL)    prefix    =    "[ FATAL ] "; else
        if (msg_type==LOG_MSG_DEBUG)    prefix    =    "[ DEBUG ] "; else
        if (msg_type==LOG_MSG_DIMMED)    prefix    =    "          "; else
        if (msg_type==LOG_MSG_DEBUG)    prefix    =    "          "; else
                                        prefix    =    "          ";

        if (log_file) {
            fputs(va("[%02d:%02d:%02d.%03d] : ", h, m, s, ms), log_file);
            fputs(prefix, log_file);
            fputs(message, log_file);
            fputs("\n", log_file);
            fflush(log_file);
        }
    #endif

    OutputDebugString(va("    [%02d:%02d:%02d.%03d] %s\r\n", h, m, s, ms, message));

    //    _CrtDbgReport(_CRT_WARN, 0, 0, NULL, va("[%02d:%02d:%02d.%03d] %s\r\n", h, m, s, ms, message));

    return msg_id;
}

void ELog::SetWriteCB(ELogWriteCB_f write_cb, void *self)
{
    this->write_cb        = write_cb;
    this->write_cb_self    = self;
}

void ELog::GetLogMessage( uint line, ELogMessage_s &message ) const
{
    if (line>=GetLogMessageNum()) {
        strcpy(message.message, "");
        message.src_file    =    "";
        message.src_line    =    0;
        message.msg_type    =    LOG_MSG_INFO;
        return;
    }

    uint n = (total_lines - line - 1) % LOG_MAX_LINES;

    memcpy( &message, &log_lines[ n ], sizeof(ELogMessage_s) );
}

void ELog::GetLogLastMessage( ELogMessage_s &message ) const
{
    memcpy( &message, &log_lines[ current_line-1 ], sizeof(ELogMessage_s) );
}

uint ELog::GetLogMessageNum( void ) const
{
    return min(total_lines, LOG_MAX_LINES);
}

void ELog::LogSplit( const char *_headline, char fill_char )
{
    if (strlen(_headline)>0) {
        LogMessage(LOG_MSG_INFO, "", 0, "");
    }

    string    headline    =    _headline;

    if (headline.length()>60) {
        headline.resize(60);
        headline += "...";
    }

    const int len = 71;
    char split[len];
    memset(split, fill_char, len);
    split[len-3] = '\r';
    split[len-2] = '\n';
    split[len-1] = '\0';

    char insert[len] = "";
    if (strlen(_headline)!=0) {
        sprintf(insert, " %s ", headline.c_str());
    }

    memcpy(split+4, insert, strlen(insert));

    LogMessage(LOG_MSG_INFO, "", 0, "%s", split);;

    if (strlen(_headline)==0) {
        LogMessage(LOG_MSG_INFO, "", 0, "");
    }
}

void ELog::AddDebugString( const char *frmt, ... )
{
    if (debug_strings_num>=LOG_MAX_DEBUG_STRINGS) {
        return;
    }

    uint i = debug_strings_num;
    debug_strings_num++;

    va_list    argptr;
    va_start (argptr, frmt);
    vsnprintf (debug_strings[i].message, LOG_LINE_LEN-1, frmt, argptr);
    va_end (argptr);
}

void ELog::ClearDebugStrings( void )
{
    debug_strings_num    =    NULL;
    for (uint i=0; i<LOG_MAX_DEBUG_STRINGS; i++) {
        strcpy(debug_strings[i].message, "");
    }
}

const char    * ELog::GetDebugString( uint index ) const
{
    if (index>=debug_strings_num) {
        return NULL;
    }

    return debug_strings[index].message;
}

uint ELog::GetDebugStringNum( void ) const
{
    return debug_strings_num;
}

