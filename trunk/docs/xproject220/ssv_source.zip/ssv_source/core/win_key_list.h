
// win_key_list.h - win32 keyboard mapping

#pragma once

#define KEY_LBUTTON              0x1
#define KEY_RBUTTON              0x2
#define KEY_MBUTTON              0x5
#define KEY_BACKSPACE            0x8
#define KEY_TAB                  0x9
#define KEY_ENTER                0xD
#define KEY_SHIFT                0x10
#define KEY_CTRL                 0x11
#define KEY_ALT                  0x12
#define KEY_PAUSE                0x13
#define KEY_CAPS_LOCK            0x14
#define KEY_ESCAPE               0x1B
#define KEY_SPACE                0x20
#define KEY_PGUP                 0x21
#define KEY_PGDN                 0x22
#define KEY_END                  0x23
#define KEY_HOME                 0x24
#define KEY_LEFT                 0x25
#define KEY_UP                   0x26
#define KEY_RIGHT                0x27
#define KEY_DOWN                 0x28
#define KEY_PRINTSCR             0x2C
#define KEY_INS                  0x2D
#define KEY_DEL                  0x2E
#define KEY_0                    0x30
#define KEY_1                    0x31
#define KEY_2                    0x32
#define KEY_3                    0x33
#define KEY_4                    0x34
#define KEY_5                    0x35
#define KEY_6                    0x36
#define KEY_7                    0x37
#define KEY_8                    0x38
#define KEY_9                    0x39
#define KEY_A                    0x41
#define KEY_B                    0x42
#define KEY_C                    0x43
#define KEY_D                    0x44
#define KEY_E                    0x45
#define KEY_F                    0x46
#define KEY_G                    0x47
#define KEY_H                    0x48
#define KEY_I                    0x49
#define KEY_J                    0x4A
#define KEY_K                    0x4B
#define KEY_L                    0x4C
#define KEY_M                    0x4D
#define KEY_N                    0x4E
#define KEY_O                    0x4F
#define KEY_P                    0x50
#define KEY_Q                    0x51
#define KEY_R                    0x52
#define KEY_S                    0x53
#define KEY_T                    0x54
#define KEY_U                    0x55
#define KEY_V                    0x56
#define KEY_W                    0x57
#define KEY_X                    0x58
#define KEY_Y                    0x59
#define KEY_Z                    0x5A
#define KEY_NUM_0                0x60
#define KEY_NUM_1                0x61
#define KEY_NUM_2                0x62
#define KEY_NUM_3                0x63
#define KEY_NUM_4                0x64
#define KEY_NUM_5                0x65
#define KEY_NUM_6                0x66
#define KEY_NUM_7                0x67
#define KEY_NUM_8                0x68
#define KEY_NUM_9                0x69
#define KEY_NUM_MUL              0x6A
#define KEY_NUM_ADD              0x6B
#define KEY_NUM_SUB              0x6D
#define KEY_NUM_DEC              0x6E
#define KEY_NUM_DIV              0x6F
#define KEY_F1                   0x70
#define KEY_F2                   0x71
#define KEY_F3                   0x72
#define KEY_F4                   0x73
#define KEY_F5                   0x74
#define KEY_F6                   0x75
#define KEY_F7                   0x76
#define KEY_F8                   0x77
#define KEY_F9                   0x78
#define KEY_F10                  0x79
#define KEY_F11                  0x7A
#define KEY_F12                  0x7B
#define KEY_NUM_LOCK             0x90
#define KEY_SCROLL_LOCK          0x91
#define KEY_SEMICOLON            0xBA
#define KEY_ADD                  0xBB
#define KEY_COMMA                0xBC
#define KEY_SUB                  0xBD
#define KEY_POINT                0xBE
#define KEY_SLASH                0xBF
#define KEY_TILDE                0xC0
#define KEY_LEFT_SQR_BRACKET     0xDB
#define KEY_BACKSLASH            0xDC
#define KEY_RIGHT_SQR_BRACKET    0xDD
#define KEY_QUOTE                0xDE

const char *const OS_KEY_LIST[256] = {
    NULL,
    "LBUTTON",
    "RBUTTON",
    NULL,
    NULL,
    "MBUTTON",
    NULL,
    NULL,
    "BACKSPACE",
    "TAB",
    NULL,
    NULL,
    NULL,
    "ENTER",
    NULL,
    NULL,

    "SHIFT",
    "CTRL",
    "ALT",
    "PAUSE",
    "CAPS_LOCK",
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    "ESCAPE",
    NULL,
    NULL,
    NULL,
    NULL,

    "SPACE",
    "PGUP",
    "PGDN",
    "END",
    "HOME",
    "LEFT",
    "UP",
    "RIGHT",
    "DOWN",
    NULL,
    NULL,
    NULL,
    "PRINTSCR",
    "INS",
    "DEL",
    NULL,

    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

    NULL,
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",

    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

    "NUM_0",
    "NUM_1",
    "NUM_2",
    "NUM_3",
    "NUM_4",
    "NUM_5",
    "NUM_6",
    "NUM_7",
    "NUM_8",
    "NUM_9",
    "NUM_MUL",
    "NUM_ADD",
    NULL,
    "NUM_SUB",
    "NUM_DEC",
    "NUM_DIV",

    "F1",
    "F2",
    "F3",
    "F4",
    "F5",
    "F6",
    "F7",
    "F8",
    "F9",
    "F10",
    "F11",
    "F12",
    NULL,
    NULL,
    NULL,
    NULL,

    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

    "NUM_LOCK",
    "SCROLL_LOCK",
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    "SEMICOLON",
    "ADD",
    "COMMA",
    "SUB",
    "POINT",
    "SLASH",

    "TILDE",
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    "LEFT_SQR_BRACKET",
    "BACKSLASH",
    "RIGHT_SQR_BRACKET",
    "QUOTE",
    NULL,

    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
};
