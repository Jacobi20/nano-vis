

#include "core_local.h"

#include "win_filesys.h"
#include "win_inputsys.h"
#include "shell.h"
#include "config.h"

void InitCoreSubsystems( void )
{
    LOG_SPLIT("Core subsystem initialization");

    Linker()->LinkFileSystem    ( new EWinFileSystem() );
    Linker()->LinkShell            ( new EShell() );
    Linker()->LinkConfig        ( new EConfig() );
    Linker()->LinkInputSystem    ( new EWinInputSystem() );

    LOG_SPLIT("");
}

void ShutdownCoreSubsystems( void )
{
    LOG_SPLIT("Core subsystem shutting down");

    Linker()->LinkInputSystem    ( NULL );
    Linker()->LinkConfig        ( NULL );
    Linker()->LinkShell            ( NULL );
    Linker()->LinkFileSystem    ( NULL );

    LOG_SPLIT("");
}
