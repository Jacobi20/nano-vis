

#include "../library.h"
#include "../math/oriented_bbox.h"

EOrientedBBox::EOrientedBBox( void )
{
    SetExtents(0,0,0);
    SetPosition(EVec3(0,0,0));
    SetOrient(QuatIdentity());
}

EOrientedBBox::EOrientedBBox( float sx, float sy, float sz )
{
    SetExtents(sx, sy, sz);
    SetPosition(EVec3(0, 0, 0));
    SetOrient(QuatIdentity());
}

EOrientedBBox::~EOrientedBBox( void )
{

}

void EOrientedBBox::SetExtents( float sx, float sy, float sz )
{
    extents.x    =    sx;
    extents.y    =    sy;
    extents.z    =    sz;
}

void EOrientedBBox::SetPosition( const EVec3 &pos )
{
    center    =    pos;
}

void EOrientedBBox::SetOrient( const EQuat &q )
{
    orient = q;
}
