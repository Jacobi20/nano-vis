

#include "../library.h"

EBBox::EBBox( void )
{
    MakeSingular();
}

EBBox::EBBox( const EBBox &other )
{
    pmin    =    other.pmin;
    pmax    =    other.pmax;
}

EBBox::EBBox( const EVec4 &p1, const EVec4 &p2 )
{
    MakeSingular();
    Expand( p1 );
    Expand( p2 );
}

EBBox::EBBox( const EVec4 &center, float szx, float szy, float szz )
{
    ASSERT( center.w );
    EVec4    pp = EVec4(center.x/center.w, center.y/center.w, center.z/center.w, 1);

    pmin    =    pp;
    pmax    =    pp;

    pmin.x    -=    szx/2.0f;
    pmin.y    -=    szy/2.0f;
    pmin.z    -=    szz/2.0f;

    pmax.x    +=    szx/2.0f;
    pmax.y    +=    szy/2.0f;
    pmax.z    +=    szz/2.0f;
}

EBBox::~EBBox( void )
{

}

void EBBox::MakeSingular( void )
{
    pmin    =    EVec4( MAX_FLOAT_VALUE, MAX_FLOAT_VALUE, MAX_FLOAT_VALUE, 1 );
    pmax    =    EVec4(-MAX_FLOAT_VALUE,-MAX_FLOAT_VALUE,-MAX_FLOAT_VALUE, 1 );
}

void EBBox::Expand( const EVec4 &p )
{
    ASSERT( p.w );
    EVec4    pp = EVec4(p.x/p.w, p.y/p.w, p.z/p.w, 1);
    if (pmin.x > pp.x) pmin.x = pp.x;
    if (pmin.y > pp.y) pmin.y = pp.y;
    if (pmin.z > pp.z) pmin.z = pp.z;

    if (pmax.x < pp.x) pmax.x = pp.x;
    if (pmax.y < pp.y) pmax.y = pp.y;
    if (pmax.z < pp.z) pmax.z = pp.z;
}

EVec4 EBBox::Min( void ) const
{
    return pmin;
}

EVec4 EBBox::Max( void ) const
{
    return pmax;
}

EVec4 EBBox::Center( void ) const
{
    return  0.5f * (pmin + pmax);
}

bool EBBox::Contains( const EVec4 &p ) const
{
    ASSERT( p.w );
    EVec4    pp = EVec4(p.x/p.w, p.y/p.w, p.z/p.w, 1);
    if (pp.x > pmax.x) return false;
    if (pp.y > pmax.y) return false;
    if (pp.z > pmax.z) return false;
    if (pp.x < pmin.x) return false;
    if (pp.y < pmin.y) return false;
    if (pp.z < pmin.z) return false;
    return true;
}

bool EBBox::Intersects( const EBBox &other ) const
{
    return
        (pmin.x < other.pmax.x) && (pmax.x > other.pmin.x) &&
        (pmin.y < other.pmax.y) && (pmax.y > other.pmin.y) &&
        (pmin.z < other.pmax.z) && (pmax.z > other.pmin.z);
}

EVec3 EBBox::Size( void ) const
{
    EVec4 sz = pmax - pmin;
    return EVec3(sz.x, sz.y, sz.z);
}

bool BBoxAABBTest( const EBBox &a, const EBBox &b )
{
    return a.Intersects( b );
}

bool BBoxOBBTest( const EBBox &a, const EVec4 &ap, const EQuat &ao, const EBBox &b, const EVec4 &bp, const EQuat &bo )
{
    return true;
}

