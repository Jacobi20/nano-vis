

#pragma once

class    EQuat    {
    public:
        EQuat();
        EQuat( const float * );
        EQuat( float x, float y, float z, float w );

        operator float* ();
        operator const float* () const;

        float            *Ptr    ( void ) { return &x; }
        const    float    *Ptr    ( void ) const { return &x; }

        EQuat& operator += ( const EQuat &q );
        EQuat& operator -= ( const EQuat &q );
        EQuat& operator *= ( const EQuat &q );
        EQuat& operator /= ( const EQuat &q );
        EQuat& operator *= ( float );
        EQuat& operator /= ( float );

        EQuat operator + () const;
        EQuat operator - () const;

        EQuat operator + ( const EQuat &q ) const;
        EQuat operator - ( const EQuat &q ) const;
        EQuat operator * ( const EQuat &q ) const;
        EQuat operator / ( const EQuat &q ) const;
        EQuat operator * ( float a ) const;
        EQuat operator / ( float a ) const;

        friend EQuat operator * ( float a, const EQuat &q );

        bool operator == ( const EQuat &q ) const;
        bool operator != ( const EQuat &q ) const;

    public:
        float x,y,z;
        float w;
    };

EQuat        QuatConjugate        ( const EQuat &q );
float        QuatDot                ( const EQuat &q1, const EQuat &q2 );
EQuat        QuatIdentity        ( void );
EQuat        QuatInverse            ( const EQuat &q );
float        QuatLength            ( const EQuat &q );
float        QuatLengthSqr        ( const EQuat &q );
EQuat        QuatMultiply        ( const EQuat &q1, const EQuat &q2 );
EQuat        QuatNormalize        ( const EQuat &q );
EQuat        QuatRotationAxis    ( float angle, const EVec3 &axis );
EVec4        QuatRotateVector    ( const EVec4 &v, const EQuat &q );
EQuat        QuatSLerp            ( const EQuat &q1, const EQuat &q2, float t );
EMatrix4    QuatToMatrix        ( const EQuat q );
EQuat        QuatFromMatrix        ( const EMatrix4 &m );
void        QuatToAngles        ( const EQuat &q, float &yaw, float &pitch, float &roll );
EQuat        QuatFromAngles        ( float yaw, float pitch, float roll );

