

#include "../library.h"

ESphere::ESphere( void )
{
    SetPosition( EVec4(0,0,0,1) );
    SetRadius( 0 );
}

ESphere::ESphere( const EVec4 &pos, float r  )
{
    SetPosition( pos );
    SetRadius( r );
}

void ESphere::SetPosition( const EVec4 &pos )
{
    ASSERT(pos.w);
    position    =    pos;
    position    /=    pos.w;
}

EVec4 ESphere::GetPosition( void ) const
{
    return position;
}

void ESphere::SetRadius( float r )
{
    radius    =    r;
}

float ESphere::GetRadius( void ) const
{
    return radius;
}

bool ESphere::IsPointInside( const EVec4 &point )  const
{
    ASSERT(point.w);

    float dist = Vec4Length( point - position );
    if (dist<=radius) {
        return true;
    }
    return false;
}

bool ESphere::Intersects( const ESphere &other ) const
{
    float    distance    =    Vec4Length( position - other.position );

    if (distance <= radius + other.radius) {
        return true;
    }
    return false;
}

