

#pragma once

class    EAngles
    {
    public:
        float    yaw;
        float    pitch;
        float    roll;

                        EAngles    ( void );
                        EAngles    ( float y, float p, float r );

        EMatrix4        ComputeRotationMatrix    ( void );
    };

inline EAngles::EAngles(void)
{
    yaw = pitch = roll = 0;
}

inline EAngles::EAngles(float y, float p, float r)
{
    yaw        =    y;
    pitch    =    p;
    roll    =    r;
}

inline EMatrix4 EAngles::ComputeRotationMatrix(void)
{
    return EMatrix4();
}
