

class    ECplx
    {
    public:
        float    a, b;

                    ECplx    ( void );
                    ECplx    ( float a, float b = 0);
                    ECplx    ( const ECplx &C );

        ECplx        operator -    ( void ) const;
        ECplx        operator +    ( const ECplx &B ) const;
        ECplx        operator -    ( const ECplx &B ) const;
        ECplx        operator *    ( const ECplx &B ) const;
        ECplx        operator /    ( const ECplx &B ) const;

        ECplx        &operator+=    ( const ECplx &B ) { *this = ((*this) + B); return *this; }
        ECplx        &operator-=    ( const ECplx &B ) { *this = ((*this) - B); return *this; }
        ECplx        &operator*=    ( const ECplx &B ) { *this = ((*this) * B); return *this; }
        ECplx        &operator/=    ( const ECplx &B ) { *this = ((*this) / B); return *this; }

        bool        operator==    ( const ECplx &B ) const;
        bool        operator!=    ( const ECplx &B ) const;

        ECplx        Conjugate    ( void ) const;
        float        Abs            ( void ) const;
    };

inline ECplx::ECplx( void ) {
    a = b = 0.0;
}

inline ECplx::ECplx( float a, float b ) {
    this->a = a;
    this->b = b;
}

inline ECplx::ECplx( const ECplx &C ) {
    this->a = C.a;
    this->b = C.b;
}

inline ECplx    ECplx::operator - ( void ) const {
    return ECplx ( -a, -b );
}

inline ECplx    ECplx::operator + ( const ECplx &B ) const {
    return ECplx( a + B.a, b + B.b );
}

inline ECplx    ECplx::operator - ( const ECplx &B ) const {
    return ECplx( a - B.a, b - B.b );
}

inline ECplx    ECplx::operator * ( const ECplx &B ) const {
    float _a = a*B.a - b*B.b;
    float _b = b*B.a + a*B.b;
    return ECplx( _a, _b );
}

inline ECplx    ECplx::operator / ( const ECplx &B ) const {
    ECplx    C = ((*this) * B.Conjugate());
    float    d = ( B.a*B.a + B.b*B.b );
    ASSERT( d );
    return ECplx( C.a/d, C.b/d );
}

inline bool        ECplx::operator == ( const ECplx &B ) const {
    return ( a==B.a && b==B.b );
}

inline bool        ECplx::operator != ( const ECplx &B ) const {
    return !(*this == B);
}

inline ECplx    ECplx::Conjugate(void) const {
    return ECplx( a, -b );
}

inline float    ECplx::Abs(void) const {
    return sqrt( a*a + b*b );
}

