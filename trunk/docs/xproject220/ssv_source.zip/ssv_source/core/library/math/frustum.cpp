

#include "../library.h"
#include "frustum.h"

EFrustum::EFrustum( void )
{
    SetFrustum(1,1,1);
    SetPosition( EVec4(0,0,0,1) );
    SetOrient( QuatIdentity() );
}

EFrustum::~EFrustum( void )
{

}

void EFrustum::SetFrustum( float w, float h, float zf )
{
    this->w        =    w;
    this->h        =    h;
    this->zf    =    zf;
    Recompute();
}

void EFrustum::SetPosition( const EVec4 &pos )
{
    this->pos    =    pos;
    Recompute();
}

void EFrustum::SetOrient( const EQuat &q )
{
    this->orient    =    q;
    Recompute();
}

void EFrustum::Recompute( void )
{
    EMatrix4    T    =    QuatToMatrix( orient ) * Matrix4Translate(pos);
//    EMatrix4    T    =    Matrix4Translate(pos) * QuatToMatrix( orient );

    EVec4    top    =    EVec4(0, 0, 0, 1);
    EVec4    tr    =    EVec4(  w/2.0f, h/2.0f, -zf, 1 );
    EVec4    tl    =    EVec4( -w/2.0f, h/2.0f, -zf, 1 );
    EVec4    br    =    EVec4(  w/2.0f,-h/2.0f, -zf, 1 );
    EVec4    bl    =    EVec4( -w/2.0f,-h/2.0f, -zf, 1 );

    top    =    Matrix4Transform( top    , T );
    tr    =    Matrix4Transform( tr    , T );
    tl    =    Matrix4Transform( tl    , T );
    br    =    Matrix4Transform( br    , T );
    bl    =    Matrix4Transform( bl    , T );

    this->right        =    PlaneFromPoints( top, br, tr );
    this->left        =    PlaneFromPoints( top, tl, bl );
    this->top        =    PlaneFromPoints( top, tr, tl );
    this->bottom    =    PlaneFromPoints( top, bl, br );
    this->far_plane    =    PlaneFromPoints( tr, bl, tl );
}

bool EFrustum::CullPoint( const EVec4 &point ) const
{
    if ( PlaneDistance( right        , point ) > 0 )     return true;
    if ( PlaneDistance( left        , point ) > 0 )     return true;
    if ( PlaneDistance( top            , point ) > 0 )     return true;
    if ( PlaneDistance( bottom        , point ) > 0 )     return true;
    if ( PlaneDistance( far_plane    , point ) > 0 )     return true;
    return false;
}

bool EFrustum::CullSphere( const ESphere &sphere ) const
{
    EVec4    center    =    sphere.GetPosition();
    float    radius    =    sphere.GetRadius();

    if ( PlaneDistance( right        , center ) > radius)     return true;
    if ( PlaneDistance( left        , center ) > radius)     return true;
    if ( PlaneDistance( top            , center ) > radius)     return true;
    if ( PlaneDistance( bottom        , center ) > radius)     return true;
    if ( PlaneDistance( far_plane    , center ) > radius)     return true;
    return false;
}

ESphere EFrustum::GetCircumSphere( void ) const
{
    EVec4    top    =    EVec4(0, 0, 0, 1);
    EVec4    tr    =    EVec4(  w/2.0f, h/2.0f, -zf, 1 );
    EVec4    tl    =    EVec4( -w/2.0f, h/2.0f, -zf, 1 );
    EVec4    br    =    EVec4(  w/2.0f,-h/2.0f, -zf, 1 );
    EVec4    bl    =    EVec4( -w/2.0f,-h/2.0f, -zf, 1 );

    EVec4    dir    =    0.5f * ((tr - top) + (tl - top));
    float    h    =    Vec4Length( dir );

    dir            =    Vec4Normalize( dir );

    float    a    =    Vec4Length( tr - top );
    float    b    =    a;
    float    c    =    Vec4Length( tr - tl );

    float    S    =    0.5 * h * c;
    float    R    =    a*b*c / 4 / S;

    EVec4    center    =    top + dir * R;

    return ESphere(center, R);
}
