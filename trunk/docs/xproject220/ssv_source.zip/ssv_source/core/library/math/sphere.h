

#pragma once

class    ESphere {
    public:
                    ESphere            ( void );
                    ESphere            ( const EVec4 &pos, float r = 0 );

        void        SetPosition        ( const EVec4 &pos );
        EVec4        GetPosition        ( void ) const;
        void        SetRadius        ( float r );
        float        GetRadius        ( void ) const;

        bool        IsPointInside    ( const EVec4 &point ) const;
        bool        Intersects        ( const ESphere &other ) const;

    protected:
        float    radius;
        EVec4    position;

    };
