

#pragma once

class    EFrustum {
    public:
                    EFrustum        ( void );
                    ~EFrustum        ( void );

        void        SetFrustum        ( float w, float h, float zf );
        void        SetPosition        ( const EVec4 &pos );
        void        SetOrient        ( const EQuat &q );

        EVec4        GetPosition        ( void ) const { return pos; }
        EQuat        GetOrient        ( void ) const { return orient; }

        bool        CullPoint        ( const EVec4 &point ) const;
        bool        CullSphere        ( const ESphere &sphere ) const;
        ESphere        GetCircumSphere    ( void ) const;

    protected:
        void        Recompute    ( void );

        float    w, h, zf;
        EVec4    pos;
        EQuat    orient;
        EPlane    right, left, top, bottom, far_plane;
    };
