

#ifndef PI
    #define    PI                3.14159265358f
#endif

const float MAX_FLOAT_VALUE    =    3.40E38f;
const float MIN_FLOAT_VALUE    =    1.18E-38f;
const float    FLOAT_EPSILON    =    1.192092896e-07f;    //    smallest positive number such that 1.0+FLT_EPSILON != 1.0

inline float sqr( float a ) { return a*a; }

#define DEG2RAD(ang)    (ang/180.0f*PI)
#define RAD2DEG(ang)    (ang*180.0f/PI)

inline float    deg2rad    ( float a ) { return a/57.295779513260928129089516840402f; }
inline float    rad2deg    ( float a ) { return a*57.295779513260928129089516840402f; }

inline float MinPositive(float a, float b) {
    if (a<0 && b<0) return MAX_FLOAT_VALUE;
    if (a<0) return b;
    if (b<0) return a;
    if (a>b) return b;
    return a;
}

inline void sincos(float a, float &s, float &c) {
    s    =    sin(a);
    c    =    cos(s);
}

uint GetBitPosition(uint64_t num);

