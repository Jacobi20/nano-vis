

#pragma once

class    EBBox {
    public:
                    EBBox        ( void );
                    EBBox        ( const EBBox &other );
                    EBBox        ( const EVec4 &p1, const EVec4 &p2 );
                    EBBox        ( const EVec4 &center, float szx, float szy, float szz );
                    ~EBBox        ( void );

        void        MakeSingular( void );

        void        Expand        ( const EVec4 &p );
        EVec4        Min            ( void ) const;
        EVec4        Max            ( void ) const;
        EVec4        Center        ( void ) const;
        EVec3        Size        ( void ) const;

        bool        Contains    ( const EVec4 &p ) const;
        bool        Intersects    ( const EBBox &other ) const;

    protected:
        EVec4        pmin;
        EVec4        pmax;
    };

bool    BBoxAABBTest( const EBBox &a, const EBBox &b );
bool    BBoxOBBTest    ( const EBBox &a, const EVec4 &ap, const EQuat &ao,    const EBBox &b, const EVec4 &bp, const EQuat &bo );

