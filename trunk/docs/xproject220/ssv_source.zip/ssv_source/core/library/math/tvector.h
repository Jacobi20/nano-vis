

#include "../library.h"

#define INLINE    __forceinline

template <int dim=4, typename Type=float>
class    EVec
    {
    private:
        typedef    EVec<dim,Type>    vec_t;
        Type    v[dim];

    public:
                    EVec            ( void );
                    EVec            ( float *v );

        Type        Length            ( void )    const;
        Type        LengthSqr        ( void )    const;
        void        NormalizeSelf    ( void );
        vec_t        Normalize        ( void )    const;
        int            GetNearestAxis    ( void )    const;

        void        Lerp            ( vec_t &a, vec_t &b, Type time );
        void        Snap            ( vec_t &grid );

        bool        Compare            ( vec_t &a, float eps=0 ) const;
        bool        Compare            ( vec_t &a ) const;

        vec_t            operator+=        ( vec_t &a );
        vec_t            operator-=        ( vec_t &a );
        vec_t            operator*=        ( vec_t &a );
        vec_t            operator|=        ( vec_t &a );
        vec_t            operator^=        ( vec_t &a );
        vec_t            operator*=        ( Type s );

        vec_t            operator-        ( void ) const;
        friend vec_t    operator+        ( vec_t &a, vec_t &b );
        friend vec_t    operator-        ( vec_t &a, vec_t &b );
        friend vec_t    operator*        ( vec_t &a, vec_t &b );
        friend Type        operator|        ( vec_t &a, vec_t &b );
        friend vec_t    operator^        ( vec_t &a, vec_t &b );
        friend vec_t    operator*        ( vec_t &a, Type s );
        friend vec_t    operator*        ( Type s, vec_t &a );

        friend bool        operator==        ( vec_t &a, vec_t &b );
        friend bool        operator!=        ( vec_t &a, vec_t &b );

    };

template <int dim, typename Type>
EVec<dim,Type>::EVec(void)
{
    memset(v, 0, sizeof(Type)*dim);
}

template <int dim, typename Type>
EVec<dim,Type>::EVec(Type *v)
{
    for (int i=0; i<dim; i++)
        this->v[i] = v[i];
}

template <int dim, typename Type>
Type EVec<dim,Type>::Length(void) const
{
    Type sum = 0;
    for (i=0; i<dim; i++) sum+=(v[i]*v[i]);
    return sqrt(sum);
}

template <int dim, typename Type>
Type EVec<dim,Type>::Length(void) const
{
    Type sum = 0;
    for (i=0; i<dim; i++) sum+=(v[i]*v[i]);
    return sum;
}

