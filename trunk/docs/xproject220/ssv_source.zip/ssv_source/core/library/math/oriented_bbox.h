

#pragma once

class    EOrientedBBox {
    public:
                    EOrientedBBox    ( void );
                    EOrientedBBox    ( float sx, float sy, float sz );
                    ~EOrientedBBox    ( void );

        void        SetExtents        ( float sx, float sy, float sz );
        void        SetPosition        ( const EVec3 &pos );
        void        SetOrient        ( const EQuat &q );

        EVec3        GetExtents        ( void ) const { return extents; }
        EVec3        GetPosition        ( void ) const { return center; }
        EQuat        GetOrient        ( void ) const { return orient; }

    protected:
        EVec3    extents;
        EVec3    center;
        EQuat    orient;
    };

bool            OBBIntersection ( const EOrientedBBox    &a, const EOrientedBBox &b );
EOrientedBBox    OBBFromBBox        ( const EBBox &box );
