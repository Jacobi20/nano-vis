

#pragma once

void    common_parti( char *s, const char *sample );
EQuat    atoq        ( const char *str );
EVec4    atov4        ( const char *str );
EVec3    atov3        ( const char *str );
EVec2    atov2        ( const char *str );

bool    streq        ( const char *a, const char *b );

unsigned int    StupidHash(const char *str);
unsigned int    RSHash(const char *str);
unsigned int    JSHash(const char* str);

bool    WildMatch    ( const char *filter, const char *str );
bool    MatchFilter    ( const char *filter, const char *name );
bool    IsAlpha        ( char ch );
bool    IsDigit        ( char ch );

void ParseFloat3(const char *str, float &a, float &b, float &c);
void ParseFloat4(const char *str, float &a, float &b, float &c, float &d);
string    TrimString    ( const string &s );
string    DecolorizeString( const string &str );
string    RemoveExtension( const string &path );
string    ExtractDirectory( const string &path );

using namespace std;

struct ENocase {
        bool    operator() ( const string &a, const string &b ) const;
    };

struct EIHash {
        size_t    operator() ( const string &s ) const;
    };

inline bool ENocase::operator () ( const string &a, const string &b ) const
{
    string::const_iterator    p    =    a.begin();
    string::const_iterator    q    =    b.begin();

    while ( p!=a.end() && q!=b.end() && toupper(*p)==toupper(*q) )
    {
        p++;
        q++;
    }

    if (p==a.end()) return q!=b.end();
    if (q==b.end()) return false;

    return toupper(*p)<toupper(*q);
}

inline size_t EIHash::operator () ( const string &s ) const
{
    return StupidHash(s.c_str());
}

