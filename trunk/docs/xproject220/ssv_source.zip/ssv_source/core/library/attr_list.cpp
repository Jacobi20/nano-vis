

#include "library.h"
#include "attr_list.h"

EAttributeList::EAttributeList(void)
{
}

EAttributeList::~EAttributeList(void)
{
}

const char *EAttributeList::GetValue(const char *key, const char *def_value) const
{
    const pair_s *pp = FindPair(key);
    if (!pp) {
        return def_value;
    } else {
        return pp->value.c_str();
    }
}

void EAttributeList::SetValue(const char *key, const char *value)
{
    pair_s *pp = const_cast<pair_s*>(FindPair(key));
    if (!pp) {
        pair_s p;
        p.key   = key;
        p.value    = value;
        pairs.push_back(p);
    } else {
        pp->value = value;
    }
}

const EAttributeList::pair_s *EAttributeList::FindPair(const char *key) const
{
    for (uint i=0; i<pairs.size(); i++) {
        if (strcmp(key, pairs[i].key.c_str())==0) {
            return &pairs[i];
        }
    }
    return NULL;
}

void EAttributeList::AppendParams(const EAttributeList *other)
{
    for (uint i=0; i<other->pairs.size(); i++) {
        this->SetValue( other->pairs[i].key.c_str(), other->pairs[i].value.c_str() );
    }
}

uint EAttributeList::GetParamNum( void ) const
{
    return pairs.size();
}

const char *EAttributeList::GetValueByID( uint index ) const
{
    if (index > GetParamNum()) {
        return NULL;
    }

    return pairs[index].value.c_str();
}

const char *EAttributeList::GetKeyByID( uint index ) const
{
    if (index > GetParamNum()) {
        return NULL;
    }

    return pairs[index].key.c_str();
}
