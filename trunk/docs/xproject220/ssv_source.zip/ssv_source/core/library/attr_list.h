

#pragma once

class EAttributeList {
    public:
                        EAttributeList    ( void );
                        ~EAttributeList    ( void );
        const char        *GetValue        ( const char *key, const char *def_value ) const;
        void            SetValue        ( const char *key, const char *value );
        void            ClearParams        ( void ) { pairs.clear(); }
        void            AppendParams    ( const EAttributeList *other );

        uint            GetParamNum        ( void ) const;
        const char        *GetValueByID    ( uint index ) const;
        const char        *GetKeyByID        ( uint index ) const;

    protected:
        struct pair_s {
            string    key;
            string    value;
        };
        const pair_s    *FindPair    ( const char *key ) const;
        vector<pair_s>    pairs;
    };
