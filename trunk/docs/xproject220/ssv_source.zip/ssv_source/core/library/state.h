

#pragma once

#ifdef WIN32
#define ul i64
#endif
class    EState
    {
    public:
                    EState        ( void )            { ResetAll(); }
        explicit     EState        ( uint bit )        { Set(bit); }
        void        Set            ( uint bit )        { ASSERT(bit<64);               state |= (  (int64_t)1ul <<(int64_t)bit);  }
        void        Reset        ( uint bit )        { ASSERT(bit<64);               state &= (~((int64_t)1ul<<(int64_t)bit)); }
        bool        Is            ( uint bit ) const    { ASSERT(bit<64); return 0 != (state &  (  (int64_t)1ul<<(int64_t)bit)); }
        void        ResetAll    ( void )            { state = 0; }

        friend EState operator | ( const EState a, const EState b ) {
            EState result;
            result.state = a.state | b.state;
            return result;
        }

        friend EState operator & ( const EState a, const EState b ) {
            EState result;
            result.state = a.state & b.state;
            return result;
        }

        friend EState operator ~( const EState a ) {
            EState result;
            result.state = ~(a.state);
            return result;
        }

    private:
        uint64_t    state;
    };

