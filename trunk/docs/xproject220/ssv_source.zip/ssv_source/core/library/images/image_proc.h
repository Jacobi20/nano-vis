

#pragma once

void ImageCopyRect(EImage &dst_image, const EImage &src_image, int dst_x, int dst_y, int w, int h, int src_x, int src_y);
