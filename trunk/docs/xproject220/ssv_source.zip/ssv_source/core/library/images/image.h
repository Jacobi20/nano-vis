

#pragma once

class  EImage {

       // EVec4 const_ref_vec4 = EVec4(0,0,0,1);
    public:
                EImage    ( void );
                EImage    ( uint w, uint h );
                ~EImage    ( void );

        void    CreateImage    ( uint w, uint h, const EVec4& fill_color =( EVec4(0,0,0,1)) );

        uint    Width        ( void ) const { return width; }
        uint    Height        ( void ) const { return height; }

        uint    OffsetC        ( int x, int y ) const;
        uint    OffsetW        ( int x, int y ) const;
        EVec4    ReadC        ( int x, int y ) const;
        EVec4    ReadW        ( int x, int y ) const;
        void    WriteC        ( int x, int y, const EVec4 &clr );
        void    WriteW        ( int x, int y, const EVec4 &clr );
        EVec4    ReadLinearC    ( float x, float y ) const;

    protected:
        uint width;
        uint height;
        vector<EVec4>    image_data;
    };

