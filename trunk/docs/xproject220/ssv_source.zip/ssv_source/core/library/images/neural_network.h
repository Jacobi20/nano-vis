

#pragma once

#include "..\library\library.h"

const uint NN_MAX_LAYERS    =    16;

class EPerceptron {
    friend class ENeuralNetwork;
    public:
                        EPerceptron        ( uint num_inputs );
                        ~EPerceptron    ( void );
        float            Evaluate        ( const vector<float> &input ) const;
    protected:
        vector<float>    weights;
    };

class ENetworkLayer {
    friend class ENeuralNetwork;
    public:
                        ENetworkLayer    ( uint num_slps, uint num_inputs );
                        ~ENetworkLayer    ( void );
        void            Evaluate        ( const vector<float> &input, vector<float> &output ) const;

    protected:
        uint    input_number;
        vector<EPerceptron*> slps;
    };

class ENeuralNetwork {
    public:
                    ENeuralNetwork        ( uint num_inputs, uint num_layers, const uint *num_perceptron);
                    ~ENeuralNetwork        ( void );

        void        EvaluateNetwork        ( const vector<float> &input, vector<float> &output ) const;
        float        TrainNetwork        ( const vector<float> &input, const vector<float> &target_output, float train_norm );

    protected:
        vector<ENetworkLayer*>    layers;
    };
