

#include "../library.h"

void ImageCopyRect(EImage &dst_image, const EImage &src_image, int dst_x, int dst_y, int w, int h, int src_x, int src_y)
{
    for (int x=0; x<w; x++)
    {
        for (int y=0; y<h; y++)
        {
            EVec4 color = src_image.ReadC(x + src_x, y + src_y);

            dst_image.WriteC(x + dst_x, y + dst_y, color);
        }
    }
}
