

#if 0

#include "neural_network.h"

float NNRandf(void) {
    float r = (float)( rand()%10000 );
    return r / 10000.0f;
}

float NNSigmoid(float x) {
    return 1.0f / (1.0f + expf(-x));
}

float NNSigmoidDerivative(float x) {
    return ( NNSigmoid(x) * (1.0f - NNSigmoid(x)) );
}

float NNSigmoidDerivativeSigm(float sigm) {
    return ( sigm * (1.0f - sigm ) );
}

float NNSqr(float x)
{
    return x * x;
}

EPerceptron::EPerceptron(uint num_inputs)
{
    weights.resize(num_inputs+1);
    for (uint i=0; i<weights.size(); i++) {
        weights[i] = 0.6f * NNRandf() - 0.3f;
    }
}

EPerceptron::~EPerceptron(void)
{
}

float EPerceptron::Evaluate(const vector<float> &input) const
{
    if ( input.size() != weights.size()-1 ) {
        RAISE_EXCEPTION(va("wrong number of inputs %d, should be %d", input.size(), weights.size()-1));
    }

    float net = 0;

    for (uint i=0; i<weights.size()-1; i++) {
        net += input[i] * weights[i];
    }

    net += weights[ weights.size()-1 ];

    return NNSigmoid(net);
}

ENetworkLayer::ENetworkLayer(uint num_perceptrons, uint num_inputs)
{
    input_number    =    num_inputs;

    slps.resize(num_perceptrons);

    for (uint i=0; i<num_perceptrons; i++) {
        EPerceptron *p = new EPerceptron(num_inputs);
        slps[i] = p;
    }
}

ENetworkLayer::~ENetworkLayer(void)
{
    for (uint i=0; i<slps.size(); i++) {
        delete slps[i];
    }
    slps.clear();
}

void ENetworkLayer::Evaluate(const vector<float> &input, vector<float> &output) const
{
    output.resize( slps.size() );

    for (uint i=0; i<slps.size(); i++) {
        output[i] = slps[i]->Evaluate(input);
    }
}

ENeuralNetwork::ENeuralNetwork(uint num_inputs, uint num_layers, const uint *num_perceptron)
{
    if (num_layers > NN_MAX_LAYERS) {
        RAISE_EXCEPTION(va("number of layers exceeded %d", NN_MAX_LAYERS));
    }

    for (uint i=0; i<num_layers; i++) {
        uint num_p, num_in;

        if (i==0) {
            num_p  = num_perceptron[0];
            num_in = num_inputs;
        } else {
            num_p  = num_perceptron[i];
            num_in = num_perceptron[i-1];
        }

        layers.push_back( new ENetworkLayer(num_p, num_in) );
    }
}

ENeuralNetwork::~ENeuralNetwork(void)
{
    for (uint i=0; i<layers.size(); i++) {
        delete layers[i];
    }
    layers.clear();
}

void ENeuralNetwork::EvaluateNetwork(const vector<float> &input, vector<float> &output) const
{

    // temp[0] contains input values

    // temp[i+1] conatins output result of layer[i]

    vector<float>    temp[NN_MAX_LAYERS+1];

    temp[0] = input;

    for (uint i=0; i<layers.size(); i++) {
        layers[i]->Evaluate( temp[i], temp[i+1] );
    }

    output = temp[i];
}

float ENeuralNetwork::TrainNetwork(const vector<float> &input, const vector<float> &target_output, float train_norm)
{
    vector<float>    actual_output;

    EvaluateNetwork(input, actual_output);

    if (actual_output.size() != target_output.size()) {
        RAISE_EXCEPTION(va("wrong target output size %d, should be %d", target_output.size(), actual_output.size()));
    }

    float err = 0;
    for (uint i=0; i<actual_output.size(); i++) {
        err += NNSqr( actual_output[i] - target_output[i] );
    }

    err *= 0.5;

    // temp[0] contains input values.

    // temp[i+1] conatins output result of layer[i]

    vector<float>    temp[NN_MAX_LAYERS+1];
    uint layer_num = (uint)layers.size();

    temp[0] = input;

    for (uint i=0; i<layers.size(); i++) {
        layers[i]->Evaluate( temp[i], temp[i+1] );
    }

    vector<float> delta[NN_MAX_LAYERS+1];
    for (uint i=0; i<NN_MAX_LAYERS+1; i++) {
        delta[i].resize( temp[i].size() );
    }

    for (uint j=0; j<delta[layer_num].size(); j++) {
        float oj = actual_output[j];
        float tj = target_output[j];
        delta[layer_num][j] = ( tj - oj ) * NNSigmoidDerivativeSigm( oj );
    }

    for (uint i = layer_num-1; i>0; i--)
    {
        uint prev_layer = i + 1;
        uint crnt_layer = i;

        for (uint j=0; j<layers[crnt_layer-1]->slps.size(); j++)
        {
            EPerceptron *slp_j = layers[crnt_layer-1]->slps[j];
            float prev_error = 0;

            for (uint k=0; k < layers[prev_layer-1]->slps.size(); k++)
            {
                prev_error += delta[prev_layer][k] * layers[prev_layer-1]->slps[k]->weights[j];
            }

            delta[crnt_layer][j] = prev_error * NNSigmoidDerivativeSigm( temp[crnt_layer][j] );
        }

    }

    for (uint i = 1; i<layer_num+1; i++)
    {
        for (uint j=0; j < layers[i-1]->slps.size(); j++)
        {
            EPerceptron *slp_j = layers[i-1]->slps[j];

            for (uint k=0; k<slp_j->weights.size()-1; k++ )
            {
                slp_j->weights[k] += train_norm * delta[i][j] * temp[i-1][k];
            }

            slp_j->weights[k] += train_norm * delta[i][j];
        }
    }

    return err;
}

#endif

