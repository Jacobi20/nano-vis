

#pragma once

void    ImageExportTGA(EImage &image, vector<byte> &output_data);
void    ImageImportTGA(EImage &image, vector<byte> &input_data);
