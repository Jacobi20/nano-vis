

#pragma once

template <uint size> class EVa {
    public:
        explicit EVa    ( const char *frmt, ... ) {
            va_list    argptr;
            va_start (argptr, frmt);
            vsnprintf (buffer, size-1, frmt, argptr);
            va_end (argptr);
        }

        ~EVa    ( void ) {
        }

        const char *c_str(void) const {
            return buffer;
        }

        operator const char* () const {
            return buffer;
        }
    private:
        char buffer[size];

        EVa<size> &operator = (EVa<size> &other) {}
        EVa<size> ( EVa<size> &other ) {}
    };

typedef EVa<512> va;

