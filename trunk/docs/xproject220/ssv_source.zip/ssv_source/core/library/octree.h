

#pragma once

template <typename T, typename SpatPr, typename EqPr>
class octree {
    public:

        octree    ( void ) {
            root = NULL;
        }

        ~octree    ( void ) {
        }

        void insert    ( const T &elem ) {
            insert_recursive(elem, &root);
        }

    protected:
        struct    octree_node {
            octree_node(void) {
                memset(subnodes, 0, sizeof(subnodes));
            }
            T            data;
            octree_node    *subnodes[8];
        };

    protected:
        void insert_recursive    ( const T &elem, struct octree_node **node ) {
            if (!*node) {
                *node = new octree_node;
                (*node)->data = elem;
                return;
            }

            if (EqPr((*node)->data, elem)) {
                (*node)->data = elem;
                return;
            }

            int r = 0x7 & SpatPr((*node)->data, elem);

            insert_recursive(elem, &(*node)->subnodes[r]);
        }

    protected:
        octree_node *root;

    };
