

#include "../library.h"
#include "grammar.hpp"
#include "grammar_char.hpp"

EGRuleTermCharFunc::EGRuleTermCharFunc(acceptFuncChar_t af)
{
    func = af;
}

bool EGRuleTermCharFunc::Accept(EGContextT<char> *ctxt, bool allow_cb, EGRuleT<char> *space)
{
    if (func(ctxt->GetSymbol())) {
        ctxt->Next();
        return true;
    }
    return false;
}

EGRuleTermCharString::EGRuleTermCharString(const char *t)
{
    term = t;
}

bool EGRuleTermCharString::Accept(EGContextT<char> *ctxt, bool allow_cb, EGRuleT<char> *space)
{
    for (uint i=0; i<term.length(); i++) {
        if (ctxt->GetSymbol()==term[i]) {
            ctxt->Next();
        } else {
            return false;
        }
    }
    return true;
}

