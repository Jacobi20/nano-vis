

#pragma once

template <class Type>
class    EStaticSingleton
    {
    public:
        static    Type    *Instance    ( void );
    };

template <class Type>
Type *EStaticSingleton<Type>::Instance(void)
{
    static    Type    inst;
    return    &inst;
}

template <class Type>
class    EUndyingSingleton
    {
    public:
        static    Type    *Instance    (void);
    };

template <class Type>
Type *EUndyingSingleton<Type>::Instance(void)
{
    static char    buffer[sizeof(Type)];
    static Type    *inst = NULL;

    if (!inst)
    {
        new (buffer) Type;
        inst =    reinterpret_cast<Type*>(buffer);
    }

    return inst;
}

