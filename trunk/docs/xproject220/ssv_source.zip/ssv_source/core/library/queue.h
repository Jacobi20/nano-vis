

template <class Type>class TQueue
    {

    };
