

#pragma once

template <class Type> class EArray {
    public:
        EArray    ( void );
        EArray    ( const EArray &other );
        ~EArray    ( void );

        uint        size        ( void ) const;
        void        resize        ( uint new_length );
        void        resize        ( uint new_length, Type a );
        Type        operator[]    ( uint n ) const;
        Type        &operator[]    ( uint n );
        EArray        &operator=    ( const EArray &other );
        void        clear        ( void );

    private:
        uint data_size;
        Type *data;
    };

template<class Type> EArray<Type>::EArray(void)
{
    data = NULL;
    data_size = 0;
}

template<class Type> EArray<Type>::~EArray(void)
{
    clear();
}

template<class Type> EArray<Type>::EArray(const EArray &other)
{
    *this = other;
}

template<class Type> uint EArray<Type>::size(void) const
{
    return data_size;
}

template<class Type> void EArray<Type>::resize(uint new_size)
{
    if (data_size == new_size) {
        return;
    }

    if (data_size==0) {
        delete[] data;
        data = NULL;
        data_size = 0;
    }

    Type *temp = data;
    data = new Type[new_size];

    for (uint i=0; i<min(data_size, new_size); i++) {
        data[i] = temp[i];
    }

    delete[] temp;

    data_size = new_size;
}

template<class Type> void EArray<Type>::resize(uint new_size, Type a)
{
    if (data_size == new_size) {
        return;
    }

    if (data_size==0) {
        delete[] data;
        data = NULL;
        data_size = 0;
    }

    Type *temp = data;
    data = new Type[new_size];

    for (uint i=0; i<min(data_size, new_size); i++) {
        data[i] = temp[i];
    }

    if (new_size > data_size) {
        for (uint i=data_size; i<new_size; i++) {
            data[i] = a;
        }
    }

    delete[] temp;

    data_size = new_size;
}

template<class Type> EArray<Type> &EArray<Type>::operator =(const EArray<Type> &other)
{
    delete[] data;

    if (other.data_size==0) {
        return *this;
    }

    data_size    =    other.data_size;
    data = new Type[data_size];

    for (uint i=0; i<data_size; i++) {
        data[i] = other.data[i];
    }

    return *this;
}

template<class Type> Type EArray<Type>::operator [](uint n) const
{
    ASSERT(data_size);
    ASSERT(n<data_size);
    return data[n];
}

template<class Type> Type &EArray<Type>::operator [](uint n)
{
    ASSERT(data_size);
    ASSERT(n<data_size);
    return data[n];
}

template<class Type> void EArray<Type>::clear(void)
{
    data_size = 0;
    delete[] data;
    data = NULL;
}
