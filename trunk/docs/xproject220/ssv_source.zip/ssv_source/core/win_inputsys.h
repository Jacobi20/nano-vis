

#pragma once

struct    bind_t
    {
        const char    *name;
        string    bind_cmd;
        string    key_func;
        string    key_func_arg;
        bool    is_pressed;
    };

struct EInputState_s {
        EInputState_s    ( void ) { target_hwnd = NULL; input_mode = 0; }
        ~EInputState_s    ( void ) {  }
        void            *target_hwnd;
        uint            input_mode;
        queue<char>        keys;
        queue<char>        chars;
        mouseInput_s    mouse;
        string            mouse_func;
    };

class    EWinInputSystem : public IInputSystem
    {
    public:
                            EWinInputSystem        ( void );
                            ~EWinInputSystem    ( void );
        virtual void        SetTargetWindow        ( void *hwnd );

        virtual void        ProcessInput        ( void );
        virtual void        GetMouseInput        ( mouseInput_s &mi );
        virtual char        GetKbChar            ( void ) { return 0; }
        virtual char        GetKbKey            ( void ) { return 0; }

        virtual    void        SaveKeyBindings        ( IPxFile file );
        virtual    uint        GetKeyByCmd            ( const char *cmd );
        virtual void        SetInputMode        ( uint flags );

    private:
        IPxFileSystem    fs;
        IPxShell        shell;

        void        InitKeyNames        ( void );
        uint        GetKeyCode            ( const char *name );

        void        ScanKeyboard        ( bool enable_scan );
        void        HandleMouse            ( bool show_cursor, bool clip, bool relative );
        bool        IsTargetWndActive    ( void );

        bind_t    bindlist[256];

        EInputState_s    state;

        void            ProcessInput(void *wnd, bool enable_scan, bool relative_mmove, bool clip_cursor, bool show_cursor, mouseInput_s &mouse);

        static void        ListBinds_f        ( EWinInputSystem *self, int argc, const char **argv);
        static void     ListKeys_f        ( EWinInputSystem *self, int argc, const char **argv);
        static void        Bind_f            ( EWinInputSystem *self, int argc, const char **argv);
        static void        Unbind_f        ( EWinInputSystem *self, int argc, const char **argv);
        static void        UnbindAll_f        ( EWinInputSystem *self, int argc, const char **argv);

        static int        SetMouseFunc    ( lua_State *L );
        static int        SetKeyFunc        ( lua_State *L );
    };
