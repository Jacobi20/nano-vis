

#pragma once

#define LUA_STACK_GUARD(lua_state)    ELuaStackGuard __lua_stack_guard__(lua_state, __FILE__, __LINE__);
#define LUA_STACK_SET_NRESULTS(n)    __lua_stack_guard__.SetNResults(n);

class ELuaStackGuard {
    public:
        ELuaStackGuard    ( lua_State *L, const char *file, uint line ) {
            this->L        = L;
            stack_top    = lua_gettop( L );
            num_results    = 0;
            this->file    = file;
            this->line    = line;
        }

        ~ELuaStackGuard    ( void ) {
            int top = lua_gettop(L);
            if (stack_top+num_results != top) {
                LOG_WARNING("%s(%d) : Lua stack guard : e=%d, l=%d, r=%d", file, line, stack_top, top, num_results);
                lua_settop( L, stack_top + num_results );
            }
        }

        void    SetNResults(int n) {
            num_results = n;
        }

    private:
        int            num_results;
        int            stack_top;
        lua_State    *L;
        const char    *file;
        uint        line;
    };
