

#pragma once

#include "lua_guard.h"

CORE_API bool        LuaGetField                ( lua_State *L, int tidx, const char *key, bool  &value );
CORE_API bool        LuaGetField                ( lua_State *L, int tidx, const char *key, int     &value );
CORE_API bool        LuaGetField                ( lua_State *L, int tidx, const char *key, uint     &value );
CORE_API bool        LuaGetField                ( lua_State *L, int tidx, const char *key, float &value );
CORE_API bool        LuaGetField                ( lua_State *L, int tidx, const char *key, EName &value );
CORE_API bool        LuaGetField                ( lua_State *L, int tidx, const char *key, EVec4 &value );
CORE_API bool        LuaGetField                ( lua_State *L, int tidx, const char *key, EQuat &value );
CORE_API bool        LuaGetSubTable            ( lua_State *L, int tidx, const char *key );

CORE_API void        LuaDefineCFunction        ( lua_State *L, const char *name, lua_CFunction cfunc, void *self );
CORE_API void        *LuaGetSelf                ( lua_State *L ) ;

CORE_API void        *LuaToUData                ( lua_State *L, int idx, const char *tname);
CORE_API bool        LuaIsUData                ( lua_State *L, int idx, const char *tname);

CORE_API void        LuaArgumentError        ( lua_State *L, int arg, const char *type, const char *what ) ;
CORE_API const char *LuaRequireString        ( lua_State *L, int arg, const char *what ) ;
CORE_API double        LuaRequireNumber        ( lua_State *L, int arg, const char *what ) ;
CORE_API bool        LuaRequireBoolean        ( lua_State *L, int arg, const char *what ) ;
CORE_API void        LuaRequireUserData        ( lua_State *L, int arg, const char *what ) ;
CORE_API void        *LuaRequireUData        ( lua_State *L, int arg, const char *tname, const char *what ) ;
CORE_API void        LuaRequireTable            ( lua_State *L, int arg, const char *what ) ;
CORE_API double        LuaRequireFieldNumeric    ( lua_State *L, int table_index, const char *field );
CORE_API bool        LuaRequireFieldBoolean    ( lua_State *L, int table_index, const char *field );
CORE_API EName        LuaRequireFieldString    ( lua_State *L, int table_index, const char *field );

CORE_API void        LuaRegisterMethods        ( lua_State *L, const char *classname, const luaL_Reg *api );
