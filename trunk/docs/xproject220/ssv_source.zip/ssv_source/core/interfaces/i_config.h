

#pragma once

class IVar;
typedef hard_ref<IVar>    IPxVar;

const uint CVAR_USER        =    0x0001;

#define CONFIG_REGISTER_VAR(var, value)    do {                    \
        var    =    Linker()->GetConfig()->RegisterVar(#var, 0);    \
        if (var->Nil()) var->Set(value);                        \
    } while (0)

class IVar : public IDisposable {
    public:
        virtual void        Set        ( bool value ) = 0;
        virtual void        Set        ( int value ) = 0;
        virtual void        Set        ( uint value ) { Set((int)value); }
        virtual void        Set        ( float value ) = 0;
        virtual void        Set        ( const char *value ) = 0;

        virtual bool        Nil        ( void ) const = 0;
        virtual bool        Bool    ( void ) const = 0;
        virtual int            Int        ( void ) const = 0;
        virtual float        Float    ( void ) const = 0;
        virtual const char *String    ( void ) const = 0;

        virtual EName        Name    ( void ) const = 0;
        virtual uint        Flags    ( void ) const = 0;
    };

class IConfig : public IDisposable {
    public:
        virtual void        SetUser            ( const char *username ) = 0;
        virtual const char    *GetUser        ( void ) const = 0;
        virtual IPxVar        RegisterVar        ( const char *name, uint flag ) = 0;
        virtual void        LoadConfig        ( void ) = 0;
        virtual void        SaveConfig        ( void ) = 0;
    };
