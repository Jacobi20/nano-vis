

struct    systemTime_t {
        word    year,    month,    day_of_week,    day;
        word    hour,    minute,    sec,    msec;
    };

#define SYS_CALL    __stdcall

typedef    uint    thread_t;
typedef uint    (SYS_CALL* threadFunc_f)    ( void *param );

class IDLL : public IDisposable {
    public:
        virtual                    ~IDLL            ( void ) {};
        virtual    void*            GetProcAddr        ( const char *func_name ) = 0;
    };

typedef hard_ref<IDLL>    IPxDLL;

class ISystem {
    public:
        virtual                    ~ISystem        ( void ) {};

        virtual const char        *GetCmdLine        ( void ) = 0;

        virtual    uint            Milliseconds    ( void ) = 0;
        virtual    systemTime_t    GetGMTTime        ( void ) = 0;
        virtual    systemTime_t    GetLocalTime    ( void ) = 0;

        virtual    void            Quit            ( uint code ) = 0;
        virtual void            Terminate        ( uint code ) = 0;

        virtual IPxDLL            LoadDLL            ( const char *dll_name ) = 0;

        virtual thread_t        SpawnThread        ( threadFunc_f func, void *param ) = 0;
        virtual void            KillThread        ( thread_t thread ) = 0;
        virtual void            Sleep            ( uint msec ) = 0;

        virtual double            MSecRDTSC        ( void ) = 0;
    };

