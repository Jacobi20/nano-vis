

#pragma once

class CORE_API IDisposable {
    public:
                        IDisposable    ( void ) : ref_count(0) { }
        virtual            ~IDisposable( void ) {  }

        virtual int        AddRef        ( void ) const {
            return InterlockedIncrement(&ref_count);
        }

        virtual int        Dispose        ( void ) const {
            ASSERT(ref_count>0);
            if (InterlockedDecrement(&ref_count)==0) {
                delete this;
                return 0;
            }
            return ref_count;
        }

        virtual int        GetRefCount    ( void ) const {
            return ref_count;
        }

        //#if 0

    private:
        mutable volatile long int ref_count;
    };

