

#pragma once

const uint ATOM_SIZE    =    256;

class    IAtomTable {
    public:
        virtual uint        Add            ( const char *str ) = 0;
        virtual uint        Add            ( uint atom ) = 0;
        virtual void        Remove        ( uint atom ) = 0;
        virtual const char    *GetName    ( uint atom ) const = 0;
    };

DLL_EXPORT    IAtomTable    *Atoms    ( void );

class    EName  {
    public:
        EName    ( void ) {
            atom = Atoms()->Add("");
            string = Atoms()->GetName(atom);
        }

        EName ( const char *str ) {
            atom = Atoms()->Add(str);
            string = Atoms()->GetName(atom);
        }

        EName    ( const EName &other ) {
            atom = other.atom;
            Atoms()->Add(atom);
            string = Atoms()->GetName(atom);
        }

        ~EName ( void ) {
            Atoms()->Remove( atom );
            atom = 0;
        }

        EName &operator = ( const EName &other ) {
            Atoms()->Remove( atom );
            atom = Atoms()->Add(other.atom);
            string = Atoms()->GetName(atom);
            return *this;
        }

        EName &operator = ( const char *str ) {
            Atoms()->Remove( atom );
            atom = Atoms()->Add(str);
            string = Atoms()->GetName(atom);
            return *this;
        }

        bool operator == ( const EName &other ) const {
            return atom==other.atom;
        }

        bool operator != ( const EName &other ) const {
            return atom!=other.atom;
        }

        const char *Name ( void ) const {
            return Atoms()->GetName( atom );
        }

    protected:
        uint        atom;
        const char *string;
    };
