

#pragma once

struct    mouseInput_s {
        int        dx;
        int        dy;
        int        x;
        int        y;
        bool    left;
        bool    right;
        bool    middle;
    };

enum EInputMode_t {
        IN_MOUSE_CLIP        =    0x0001,
        IN_MOUSE_HIDE        =    0x0002,
        IN_MOUSE_RELATIVE    =    0x0004,
        IN_KB_SCAN            =    0x0008,
        IN_KB_CHAR            =    0x0010,
    };

class IInputSystem : public IDisposable {
    public:
        virtual void        SetTargetWindow        ( void *hwnd ) = 0;

        virtual void        ProcessInput        ( void ) = 0;
        virtual void        GetMouseInput        ( mouseInput_s &mi ) = 0;
        virtual char        GetKbChar            ( void ) = 0;
        virtual char        GetKbKey            ( void ) = 0;

        virtual    void        SaveKeyBindings        ( IPxFile file ) = 0;
        virtual    uint        GetKeyByCmd            ( const char *cmd ) = 0;
        virtual void        SetInputMode        ( uint flags ) = 0;
    };
