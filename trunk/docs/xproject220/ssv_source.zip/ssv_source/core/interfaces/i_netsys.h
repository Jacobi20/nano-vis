

#pragma once

const uint SV_MAXCLIENTS    =    256;

class    ITcpListener;
class    ITcpClient;
class    IUdpClient;
class    INetworkSystem;

typedef hard_ref<ITcpListener    >    IPxTcpListener        ;
typedef hard_ref<ITcpClient        >    IPxTcpClient        ;
typedef hard_ref<IUdpClient        >    IPxUdpClient        ;
typedef hard_ref<INetworkSystem    >    IPxNetworkSystem    ;

class    INetworkSystem : public IDisposable {
    public:
        virtual    IPxTcpListener    CreateTCPListener    ( uint port ) = 0;
        virtual    IPxTcpClient    CreateTCPClient        ( void ) = 0;
        virtual    IPxUdpClient    CreateUPDClient        ( void ) = 0;
    };

class    ITcpListener : public IDisposable {
    public:
        virtual    IPxTcpClient    Accept        ( void ) = 0;
    };

class    ITcpClient : public IDisposable {
    public:
        virtual    void            Connect            ( const char *address, uint port ) = 0;
        virtual    uint            Send            ( const void *data, uint size ) = 0;
        virtual    uint            Recv            ( void *data, uint size ) = 0;
        virtual bool            IsConnected        ( void ) const = 0;
        virtual void            SetBlockMode    ( bool enable ) = 0;
    };

class    IUdpClient : public IDisposable {
    public:
        virtual    void            SetEndPoint        ( const char *address, uint port ) = 0;
        virtual    uint            Send            ( const void *data, uint size ) = 0;
        virtual    uint            Recv            ( void *data, uint size ) = 0;
        virtual void            SetBlockMode    ( bool enable ) = 0;
    };

