

#pragma once

class IGEvent;

typedef hard_ref<IGEvent>    IPxGEvent;

class IGEvent : public IDisposable {
    public:
        virtual void    SetObject    ( const char *name, uint obj_id ) = 0;
        virtual void    SetParam    ( const char *name, const char *value ) = 0;
        virtual void    SetParam    ( const char *name, const EVec4 &value ) = 0;
        virtual void    SetParam    ( const char *name, float value ) = 0;
        virtual void    SetParam    ( const char *name, int value ) = 0;
    };

class IGame : public IDisposable {
    public:
        virtual IPxGEvent    CreateEvent        ( void ) = 0;
        virtual    void        Frame            ( uint dtime ) = 0;
    };

