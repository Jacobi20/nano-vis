

#pragma once

typedef void (*EShellCmd_f)( void *self, uint argc, const char **argv );
typedef lua_CFunction        ELuaCFunc_f;

#define LUA_ERROR(s)    Linker()->GetShell()->LuaError(s)
#define LUA_WARNING(s)    Linker()->GetShell()->LuaWarning(s)

class    IShell : public IDisposable {
    public:
        virtual                ~IShell                    ( void ) {}

        virtual void        AddCommand                ( const char *name, EShellCmd_f cmd_func, void *self ) = 0;
        virtual void        RemoveCommand            ( const char *name ) = 0;
        virtual void        DefineCFunc                ( const char *name, ELuaCFunc_f lua_cfunc ) = 0;

        virtual void        ExecuteString            ( const char *cmd_text,  bool raise_error=false ) = 0;
        virtual void        ExecuteScript            ( const char *file_name, bool raise_error=false ) = 0;

        virtual const char    *CompleteCommand        ( const char *text ) = 0;

        virtual lua_State    *Lua                    ( void ) = 0;

        virtual int            LuaWarning                ( const char *text ) = 0;
        virtual int            LuaError                ( const char *text ) = 0;
    };

