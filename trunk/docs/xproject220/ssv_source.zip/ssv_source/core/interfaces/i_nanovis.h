

#pragma once

class INanoVis : public IDisposable {
    public:
        virtual void            RenderFrame            ( uint dtime ) = 0;
        virtual void            RenderSnapshot        ( const char *command ) = 0;
    };
