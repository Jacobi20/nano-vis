

#pragma once

class ILocatable : public IDisposable {
    public:
        virtual            ~ILocatable        ( void ) {  }

        virtual void    SetPose            ( const EVec4 &position, const EQuat &orient ) = 0;
        virtual void    GetPose            ( EVec4 &position, EQuat &orient ) const = 0;
        virtual void    SetVelocity        ( const EVec4 &linear_velocity ) = 0;
        virtual void    GetVelocity        ( EVec4 &linear_velocity ) const = 0;
    };

