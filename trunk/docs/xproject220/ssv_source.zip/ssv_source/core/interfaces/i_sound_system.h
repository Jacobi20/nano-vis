

#pragma once

class ISound3D;
class ISoundTrack;
class ISoundGeometry;
class ISoundReverb;

typedef hard_ref<ISound3D>        IPxSound3D;
typedef hard_ref<ISoundTrack>    IPxSoundTrack;
typedef hard_ref<ISoundGeometry>    IPxSoundGeometry;
typedef hard_ref<ISoundReverb>    IPxSoundReverb;

enum    soundReverbType_t
    {
        SOUND_REVERB_OFF = 0,
        SOUND_REVERB_GENERIC,
        SOUND_REVERB_PADDEDCELL,
        SOUND_REVERB_BATHROOM,
        SOUND_REVERB_LIVINGROOM,
        SOUND_REVERB_STONEROOM,
        SOUND_REVERB_AUDITORIUM,
        SOUND_REVERB_CONCERTHALL,
        SOUND_REVERB_CAVE,
        SOUND_REVERB_ARENA,
        SOUND_REVERB_HANGAR,
        SOUND_REVERB_CARPETTEDHALLWAY,
        SOUND_REVERB_HALLWAY,
        SOUND_REVERB_STONECORRIDOR,
        SOUND_REVERB_ALLEY,
        SOUND_REVERB_FOREST,
        SOUND_REVERB_CITY,
        SOUND_REVERB_MOUNTAINS,
        SOUND_REVERB_QUARRY,
        SOUND_REVERB_PLAIN,
        SOUND_REVERB_ROOM,
        SOUND_REVERB_PARKINGLOT,
        SOUND_REVERB_SEWERPIPE,
        SOUND_REVERB_UNDERWATER,
    };

class ISoundReverb : public IDisposable {
    public:
        virtual                    ~ISoundReverb            ( void ) {}
        virtual    void            Set3DProperties            ( const EVec4& pos, float min_distance, float max_distance ) = 0;
        virtual    EVec4            GetPosition                ( void ) = 0;
        virtual void            GetDistance                ( float &min_distance, float &max_distance ) = 0;
};

class ISoundGeometry : public IDisposable {
    public:
        virtual                    ~ISoundGeometry            ( void ) {}
        virtual    void            SetPosition                ( const EVec4 &pos ) = 0;
        virtual void            SetOrient                ( const EQuat &orient ) = 0;
};

///          ISound3D

class ISound3D : public ILocatable {
    public:
        virtual                    ~ISound3D    ( void ) {}

        virtual void            Play            ( bool loop ) = 0;

        virtual void            Stop            ( void ) = 0;

        virtual void            Pause            ( void ) = 0;

        virtual void            Unpause            ( void ) = 0;

        virtual bool            IsPlaying        ( void ) const = 0;

        ///       1.0.
        ///    @param    volume    -     .   [0..1].
        virtual void            SetVolume        ( float volume ) = 0;

        ///    ,    2,     2  ,

        ///       1.0.
        ///    @param    pitch    -      .   [0.5..2.0]

        virtual void            SetPitch        ( float pitch ) = 0;

        virtual    void            SetMute            ( bool mute ) = 0;

        virtual    void            SetSpread            ( float angle ) = 0;

        virtual    void            SetDoplerLevel        ( float level ) = 0;

        virtual    void            SetMinMaxDistance    ( float min, float max ) = 0;
    };

///       ISound3D  2D- ,   ISoundSystem::Play2DSound
///      ,    3-,   .

class ISoundTrack : public IDisposable {
    public:
        virtual                    ~ISoundTrack        ( void ) {}

        virtual    void            Play            ( void ) = 0;

        virtual void            Pause            ( void ) = 0;

        virtual void            Stop            ( void ) = 0;

        ///       1.0.
        ///    @param    volume    -     .   [0..1].
        virtual void            SetVolume        ( float volume ) = 0;

        virtual float            GetLength        ( void ) = 0;

        ///        - 0.0.

        virtual void            SetPos            ( float time ) = 0;

        virtual float            GetPos            ( void ) = 0;

        virtual    void            SetMute            ( bool mute ) = 0;
    };

///    2D-  3D-   ,

///     3D-    .

class ISoundSystem : public IDisposable {
    public:
        virtual                    ~ISoundSystem        ( void ) {}

        virtual void            FreeSounds            ( void ) = 0;

        ///      2D-.
        ///      �     (UI, HUD  ..).

        /// @param    volume    -       .   [0..1].
        /// @param    panning -      .   [-1..1]
        virtual void            Play2DSound            ( const char *path, float volume, float panning ) = 0;

        virtual void            SetListener            ( const EVec4 &pos, const EVec4 &view, const EVec4 &up, const EVec4 &vel ) = 0;

        ///      ,   ISound3D,     .
        ///        ,     (0,0,0). ..     .
        ///            ISound3D.

        virtual IPxSound3D        CreateSoundSource    ( const char *path ) = 0;

        ///       ISound3D.

        //virtual void            DestroySoundSource    ( ISound3D *sound ) = 0;

        virtual IPxSoundTrack    CreateSoundTrack    ( const char *path ) = 0;

        virtual IPxSoundGeometry CreateSoundGeometry    ( const IPxTriMesh input_mesh, const EVec4 &pos, const EQuat &orient  ) = 0;

        ///       ISound3D.

        //virtual void            DestroySoundTrack    ( ISoundTrack *track ) = 0;

        virtual void            Frame                ( void ) = 0;

        virtual    void            RenderDebug            ( void ) = 0;

        virtual    void            SetMute            ( bool mute ) = 0;

        virtual IPxSoundReverb CreateReverb ( const EVec4& pos, float min_distance, float max_distance, soundReverbType_t type ) = 0;
};
