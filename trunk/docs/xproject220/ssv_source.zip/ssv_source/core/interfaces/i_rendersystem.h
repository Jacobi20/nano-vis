

#pragma once

class    IRenderSystem;
class    IDraw2D;

class    IRScene;
class    IRSLight;
class    IRSEntity;
class    IRSShader;

typedef hard_ref<IRenderSystem            >    IPxRenderSystem            ;
typedef hard_ref<IDraw2D                >    IPxDraw2D                ;

typedef hard_ref<IRScene                >    IPxRScene            ;
typedef hard_ref<IRSLight                >    IPxRSLight            ;
typedef hard_ref<IRSEntity                >    IPxRSEntity            ;
typedef hard_ref<IRSShader                >    IPxRSShader            ;

const uint RS_GFX_MAX_STRIP_POINTS    =    16;

enum ERSLightShape_t {
        RS_LIGHT_SHAPE_SPOT=0,
        RS_LIGHT_SHAPE_OMNI,
        RS_LIGHT_SHAPE_DIRECT,
    };

enum ERSGFXBlend_t {
        RS_GFX_NORMAL,
        RS_GFX_ADDITIVE,
        RS_GFX_SUBTRACTIVE,
        RS_GFX_MULTIPLY,
        RS_GFX_LIGHTEN,
        RS_GFX_DISTORTIVE,
    };

struct ERSGFXSprite_s {
        EVec3            pos;
        EVec4            aim;
        float            angle;
        float            x_size;
        float            y_size;
        float            anim_offset;
        EVec4            color;
        EName            texture;
        ERSGFXBlend_t    blend_mode;
    };

struct ERSGFXStrip_s {
        uint            num_points;
        EVec3            points[RS_GFX_MAX_STRIP_POINTS];
        EVec4            aim;
        EVec4            color;
        float            width;
        float            anim_offset;
        EName            texture;
        ERSGFXBlend_t    blend_mode;
    };

struct ERSQuad_s {
        EVec4    color;
        EVec2    p0,  p1;
        EVec2    uv0, uv1;
    };

struct ERSLine_s {
        EVec3    v0;
        EVec4    c0;
        EVec2    uv0;

        EVec3    v1;
        EVec4    c1;
        EVec2    uv1;
    };

struct ERSVert2D_s {
        EVec4    color;
        EVec2    p;
        EVec2    uv;
    };

class IDraw2D : public IDisposable {
    public:
        virtual void    Set2DViewMode        ( float offset_x=0, float offset_y=0 ) = 0;
        virtual void    SetColorMultiplier    ( const EVec4 &color ) = 0;
        virtual    void    DrawQuads            ( uint num_quads, const ERSQuad_s *quads, const EName texture ) = 0;

        virtual void    DrawLine            ( EVec3 &v0, EVec3 &v1, EVec4 &color ) = 0;
        virtual void    DrawGrid            ( void ) = 0;

        virtual void    Begin2D                ( void ) = 0;
        virtual void    End2D                ( void ) = 0;

        virtual void    SetTransform        ( EMatrix4 &m ) { ASSERT(0); }
        virtual void    SetProjection        ( EMatrix4 &m ) { ASSERT(0); }
    };

struct ERendEntityDesc_s {
        EVec4        position;
        EQuat        orient;
        IPxTriMesh    mesh;
    };

struct    ERendLightDesc_s {
        EVec4    position;
        EQuat    orient;
        EVec4    color;
        float    radius;
        float    spot;
        bool    shadow;
        ERSLightShape_t    shape;
        EName    mask;
    };

class    IRSLight : public ILocatable {
    public:
        virtual void    UpdateLight        ( const ERendLightDesc_s *light_desc ) = 0;
        virtual void    SetColor        ( const EVec4 &color ) = 0;
        virtual void    SetRadius        ( float radius ) = 0;
        virtual void    SetVisible        ( bool visible ) = 0;
    };

class    IRSEntity : public ILocatable {
    public:
        virtual void    UpdateEntity    ( const ERendEntityDesc_s *entity_desc ) = 0;
        virtual void    Animate            ( float time ) = 0;
        virtual void    AddDecal        ( EVec3 position, EVec3 direction, float radius, EName material ) = 0;
        virtual IPxTriMesh GetTriMesh    ( void ) = 0;
    };

class    IRSShader : public IDisposable {
    public:
        virtual bool    Setup            ( void ) = 0;
        virtual EName    Name            ( void ) const = 0;
    };

class    IRScene : public IDisposable {
    public:
        virtual void            RenderScene        ( void ) = 0;

        virtual IPxRSEntity    AddEntity        ( IPxTriMesh mesh, const EVec4 &pos, const EQuat &orient ) = 0;

        virtual IPxRSLight    AddLight        ( const ERendLightDesc_s *light_desc ) = 0;
        virtual void            RemoveLight        ( IPxRSLight light ) = 0;
        virtual void            RemoveEntity    ( IPxRSEntity entity ) = 0;

        virtual void            AddStaticMesh    ( const IPxTriMesh mesh, const EVec4 &pos, const EQuat &orient ) = 0;
        virtual void            ProcessStaticGeometry ( void ) = 0;

        virtual void            SetView            ( const EVec4 &position, const EQuat &orient ) = 0;
        virtual void            SetProjection    ( float znear, float zfar, float width, float height ) = 0;
        virtual void            SetAmbientLevel    ( const EVec4 &color ) = 0;

        virtual void            DebugLine        ( const EVec3 &v0, const EVec3 &v1, const EVec4 &color  ) = 0;

        virtual void            AddGFXSprite    ( const ERSGFXSprite_s &sprite ) = 0;
        virtual void            AddGFXStrip        ( const ERSGFXStrip_s &strip ) = 0;
    };

struct  EVidModeDesc_s {
        uint    width;
        uint    height;
        bool    is_supported;
    };

class    IRenderSystem : public IDisposable {
    public:
        virtual                ~IRenderSystem        ( void ) {};

        virtual    void        BeginFrame            ( void ) = 0;
        virtual void        RenderFrame            ( IPxRScene scene ) = 0;
        virtual void        EndFrame            ( void ) = 0;

        virtual bool        CheckFallback        ( uint fallback ) = 0;

        virtual    IPxDraw2D                GetDraw2D            ( void ) = 0;

        virtual IPxRScene                CreateScene            ( void ) = 0;

        virtual void        GetScreenSize        ( uint &w, uint &h ) = 0;
        virtual void *        GetWndDescriptor    ( void ) = 0;
        virtual uint        GetCurrentMode        ( void ) = 0;
        virtual uint        GetModeNum            ( void ) = 0;
        virtual void        GetModeDesc            ( uint nmode, EVidModeDesc_s *mode_desc ) = 0;

        virtual void        GetTextureSize        ( const EName tex_name, uint &w, uint &h ) = 0;
    };

