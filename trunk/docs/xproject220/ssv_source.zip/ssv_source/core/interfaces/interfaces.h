

#pragma once

#include "i_disposable.h"
#include "i_locatable.h"

#include "i_atoms.h"
#include "i_core.h"
#include "i_log.h"
#include "i_system.h"

#include "i_config.h"
#include "i_shell.h"
#include "i_filesys.h"
#include "i_geometry.h"

#include "i_input.h"
#include "i_rendersystem.h"
#include "i_physics.h"
#include "i_game.h"
#include "i_sound_system.h"
#include "i_netsys.h"
#include "i_ui.h"

#include "i_nanovis.h"
