

#pragma once

const uint LOG_MAX_LINES    =    4096;
const uint LOG_LINE_LEN        =    256;

typedef void (*ELogWriteCB_f)(void *self);

enum ELogMsgType_t {
        LOG_MSG_INFO = 0,
        LOG_MSG_WARNING,
        LOG_MSG_ERROR,
        LOG_MSG_FATAL,
        LOG_MSG_DEBUG,
        LOG_MSG_ACTION,
        LOG_MSG_ACTION_OK,
        LOG_MSG_ACTION_FAILED,
        LOG_MSG_DIMMED,
        LOG_MSG_MAX,
    };

struct ELogMessage_s {
        ELogMsgType_t    msg_type;
        char            message[LOG_LINE_LEN];
        const char    *    src_file;
        uint            src_line;
    };

class    ILog {
    public:
        virtual    uint        LogMessage            ( ELogMsgType_t msg_type, const char *src_file, uint src_line, const char *frmt, ... ) = 0;
        virtual void        SetWriteCB            ( ELogWriteCB_f write_cb, void *self ) = 0;
        virtual void        GetLogMessage        ( uint line, ELogMessage_s &message ) const = 0;
        virtual void        GetLogLastMessage    ( ELogMessage_s &message ) const = 0;
        virtual uint        GetLogMessageNum    ( void ) const = 0;
        virtual void        Clear                ( void ) = 0;
        virtual void        LogSplit            ( const char *headline, char fill_char='-' ) = 0;

        virtual void        AddDebugString        ( const char *frmt, ... ) = 0;
        virtual void        ClearDebugStrings    ( void ) = 0;
        virtual const char    *GetDebugString        ( uint index ) const = 0;
        virtual uint        GetDebugStringNum    ( void ) const = 0;
    };

