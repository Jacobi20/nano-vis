

class IFont;
class IUIFrame;

typedef hard_ref<IFont>        IPxFont;
typedef hard_ref<IUIFrame>    IPxUIFrame;

const uint UI_MOUSE_LEFT    =    0x0001;
const uint UI_MOUSE_RIGHT    =    0x0002;
const uint UI_MOUSE_MIDDLE    =    0x0004;

const uint UI_ALIGNH_LEFT    =    0x0001;
const uint UI_ALIGNH_RIGHT    =    0x0002;
const uint UI_ALIGNH_CENTER    =    0x0004;
const uint UI_ALIGNH_FILL    =    0x0008;

const uint UI_ALIGNV_TOP    =    0x0010;
const uint UI_ALIGNV_BOTTOM    =    0x0020;
const uint UI_ALIGNV_CENTER    =    0x0040;
const uint UI_ALIGNV_FILL    =    0x0080;

struct uiRect_s {
        uiRect_s(void) { x = y = w = h = 0; }
        uiRect_s(float x, float y, float w, float h) {
            this->x = x;    this->y = y;
            this->w = w;    this->h = h;
        }
        float x, y, w, h;
    };

enum uiMouseEventType_t {
        UI_MOUSE_EVENT_NONE = 0,
        UI_MOUSE_EVENT_UP,
        UI_MOUSE_EVENT_DOWN,
        UI_MOUSE_EVENT_CLICK,
        UI_MOUSE_EVENT_IN,
        UI_MOUSE_EVENT_OUT,
        UI_MOUSE_EVENT_MOVE,
    };

struct uiMouseEvent_s {
        uiMouseEvent_s (void) { x = y = 0; mouse_event = UI_MOUSE_EVENT_NONE; button = 0; }
        uiMouseEvent_s (uiMouseEventType_t mouse_event, float x, float y, uint button) {
            this->x = x;
            this->y = y;
            this->mouse_event = mouse_event;
            this->button = button;
        }

        uiMouseEventType_t mouse_event;
        float x, y;
        uint button;
    };

class IFont : public IDisposable {
    public:
        virtual                ~IFont            ( void ) {}
        virtual const char    *Name            ( void ) const = 0;
        virtual const char    *GetFontImage    ( void ) const = 0;
        virtual float        GetLineHeight    ( void ) const = 0;
        virtual float        GetBaseLine        ( void ) const = 0;

        virtual float        GetXAdvance        ( uchar ch ) const = 0;
        virtual EVec2        GetOffset        ( uchar ch ) const = 0;
        virtual EVec2        GetUV0            ( uchar ch ) const = 0;
        virtual EVec2        GetUV1            ( uchar ch ) const = 0;
        virtual EVec2        GetGlyphSize    ( uchar ch ) const = 0;
        virtual float        GetKerning        ( uchar first, char second ) const = 0;
    };

class IUIFrame: public IDisposable {
    public:
        virtual                ~IUIFrame            ( void ) {};

        virtual void        FMKeyDown            ( uint code, bool press ) = 0;
    //    virtual void        FMKeyPress            ( uint code ) = 0;
    //    virtual void        FMKeyDown            ( uint code ) = 0;
        virtual void        FMPaint                ( void ) = 0;
        virtual void        FMMouse                ( uiMouseEvent_s mouse_event ) = 0;
    //    virtual void        FMMouseUp            ( uint button, float x, float y ) = 0;
    //    virtual void        FMMouseDown            ( uint button, float x, float y ) = 0;
    //    virtual void        FMMouseClick        ( uint button, float x, float y ) = 0;
    //    virtual void        FMMouseIn            ( void ) = 0;
    //    virtual void        FMMouseOut            ( void ) = 0;
    //    virtual void        FMMouseMove            ( uint button, float x, float y ) = 0;
        virtual void        FMProcess            ( float delta, float time ) = 0;
        virtual void        FMResize            ( float new_width, float new_height ) = 0;
        virtual void        FMMove                ( float new_x, float new_y ) = 0;
        virtual    void        FMShowFrame            ( void ) = 0;
        virtual void        FMHideFrame            ( void ) = 0;

        virtual IPxUIFrame    GetClientArea        ( void ) = 0;
        virtual bool        IsVisible            ( void ) const = 0;
        virtual bool        IsEnabled            ( void ) const = 0;
        virtual bool        IsDraggable            ( void ) const = 0;
        virtual bool        IsSizeable            ( void ) const = 0;
        virtual uiRect_s    GetFrameRect        ( void ) const = 0;
        virtual float        GetFrameOpacity        ( void ) const = 0;
        virtual void        GetScrollOffset        ( float &dx, float &dy ) = 0;
        virtual const char    *GetFrameText        ( void ) const = 0;

        virtual void        AttachChild            ( IPxUIFrame entity ) = 0;
        virtual void        DetachChild            ( IPxUIFrame entity ) = 0;
        virtual void        DetachChild            ( uint index ) = 0;
        virtual void        DetachAll            ( void ) = 0;
        virtual uint         GetChildNum            ( void ) const = 0;
        virtual IPxUIFrame     GetChild            ( uint index ) = 0;
        virtual IPxUIFrame     GetParent            ( void ) = 0;
        virtual void        SetParent            ( IPxUIFrame parent ) = 0;
    };

class IUIHook {
    public:
        virtual                ~IUIHook    ( void ) {}
        virtual void        Hook        ( uint code  ) = 0;
        virtual    uint        GetHook        ( void ) = 0;
        virtual    IPxUIFrame    GetFrame    ( void ) = 0;
        virtual    void        Clear        ( void ) = 0;
    };

class    IUserInterface : public IDisposable {
    public:
                            ~IUserInterface        ( void ) {}

        virtual void        DrawStringMT        ( float x, float y, float size, float tracking, const char *font_raster, const char *string, const EVec4 &color ) = 0;
        virtual void        DrawStringMTClr        ( float x, float y, float size, float tracking, const char *font_raster, const char *string ) = 0;
        virtual void        DrawStringFont        ( float x, float y, const IPxFont font, const char *string, const EVec4 &color=EVec4(1,1,1,1) ) = 0;
        virtual void        DrawTextInRect        ( uiRect_s &r, const IPxFont font, const char *text, uint align, const EVec4 &color=EVec4(1,1,1,1) ) = 0;
        virtual float        StringFontLength    ( const IPxFont font, const char *string ) = 0;
        virtual void        DrawRect            ( float x, float y, float w, float h, const char *image, const EVec4 &color ) = 0;
        virtual void        DrawBorderRect        ( float x, float y, float w, float h, const char *image, const EVec4 &color ) = 0;
        virtual void        DrawBorderRectTop    ( float x, float y, float w, float h, const char *image, const EVec4 &color ) = 0;
        virtual void        DrawBorderRectBottom( float x, float y, float w, float h, const char *image, const EVec4 &color ) = 0;
        virtual IPxFont        RegisterFont        ( const char *path ) = 0;

    };

