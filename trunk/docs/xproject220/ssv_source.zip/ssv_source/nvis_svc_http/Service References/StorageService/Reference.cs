��

//     Runtime Version:2.0.50727.3053

namespace nvis_svc_http.StorageService {

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", ConfigurationName="StorageService.NanoIOSystemAPIInterface")]
    public interface NanoIOSystemAPIInterface {

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.postDataResponse1 postData(nvis_svc_http.StorageService.postDataRequest1 request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="DataNotFoundException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageMethodException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="UnsupportedBasisAtomException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.getDataResponse1 getData(nvis_svc_http.StorageService.getDataRequest1 request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="DataNotFoundException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageMethodException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="UnsupportedBasisAtomException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.getDataContentResponse1 getDataContent(nvis_svc_http.StorageService.getDataContentRequest1 request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="DataNotFoundException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageMethodException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="UnsupportedBasisAtomException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.forwardDataResponse1 forwardData(nvis_svc_http.StorageService.forwardDataRequest1 request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="DataNotFoundException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageMethodException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.getMetaDataResponse1 getMetaData(nvis_svc_http.StorageService.getMetaDataRequest1 request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.listPackagesResponse listPackages(nvis_svc_http.StorageService.listPackagesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="DataNotFoundException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="IllegalCalcPackageMethodException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.getDataCharacteristicsResponse1 getDataCharacteristics(nvis_svc_http.StorageService.getDataCharacteristicsRequest1 request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.listDataIdsByTaskIdResponse listDataIdsByTaskId(nvis_svc_http.StorageService.listDataIdsByTaskIdRequest1 request);

        [System.ServiceModel.OperationContractAttribute(Action="", ReplyAction="*")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="InternalErrorException")]
        [System.ServiceModel.FaultContractAttribute(typeof(string), Action="", Name="DataNotFoundException")]
        [System.ServiceModel.XmlSerializerFormatAttribute()]
        nvis_svc_http.StorageService.getDataLengthResponse1 getDataLength(nvis_svc_http.StorageService.getDataLengthRequest1 request);
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class postDataRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIDField;

        private string taskIDField;

        private MethodParam[] paramField;

        private Atom[] atomsField;

        private string urlField;

        private byte[] contentField;

        private string calcPackageField;

        private string authorField;

        private string labelField;

        private Attribute[] metadataAttributesField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataID {
            get {
                return this.dataIDField;
            }
            set {
                this.dataIDField = value;
                this.RaisePropertyChanged("DataID");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string TaskID {
            get {
                return this.taskIDField;
            }
            set {
                this.taskIDField = value;
                this.RaisePropertyChanged("TaskID");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("Param", Order=2)]
        public MethodParam[] Param {
            get {
                return this.paramField;
            }
            set {
                this.paramField = value;
                this.RaisePropertyChanged("Param");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("Atoms", Order=3)]
        public Atom[] Atoms {
            get {
                return this.atomsField;
            }
            set {
                this.atomsField = value;
                this.RaisePropertyChanged("Atoms");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(DataType="anyURI", Order=4)]
        public string url {
            get {
                return this.urlField;
            }
            set {
                this.urlField = value;
                this.RaisePropertyChanged("url");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(DataType="base64Binary", Order=5)]
        public byte[] Content {
            get {
                return this.contentField;
            }
            set {
                this.contentField = value;
                this.RaisePropertyChanged("Content");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=6)]
        public string CalcPackage {
            get {
                return this.calcPackageField;
            }
            set {
                this.calcPackageField = value;
                this.RaisePropertyChanged("CalcPackage");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=7)]
        public string Author {
            get {
                return this.authorField;
            }
            set {
                this.authorField = value;
                this.RaisePropertyChanged("Author");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=8)]
        public string Label {
            get {
                return this.labelField;
            }
            set {
                this.labelField = value;
                this.RaisePropertyChanged("Label");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("MetadataAttributes", Order=9)]
        public Attribute[] MetadataAttributes {
            get {
                return this.metadataAttributesField;
            }
            set {
                this.metadataAttributesField = value;
                this.RaisePropertyChanged("MetadataAttributes");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class MethodParam : object, System.ComponentModel.INotifyPropertyChanged {

        private string keyField;

        private string valueField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string Key {
            get {
                return this.keyField;
            }
            set {
                this.keyField = value;
                this.RaisePropertyChanged("Key");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
                this.RaisePropertyChanged("Value");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class AtomIntAttribute : object, System.ComponentModel.INotifyPropertyChanged {

        private int atomIdField;

        private string nameField;

        private int valueField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public int AtomId {
            get {
                return this.atomIdField;
            }
            set {
                this.atomIdField = value;
                this.RaisePropertyChanged("AtomId");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string Name {
            get {
                return this.nameField;
            }
            set {
                this.nameField = value;
                this.RaisePropertyChanged("Name");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public int Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
                this.RaisePropertyChanged("Value");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class DataCharacteristics : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIDField;

        private int dimensionField;

        private int countAtomsField;

        private int countDistinctAtomsField;

        private int countBasisFunctionsField;

        private int countBasisFunctionMonomsField;

        private double minXValueField;

        private double maxXValueField;

        private double minYValueField;

        private double maxYValueField;

        private double minZValueField;

        private double maxZValueField;

        private AtomIntAttribute[] atomsTableField;

        private int exitCodeField;

        public DataCharacteristics() {
            this.dimensionField = 3;
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataID {
            get {
                return this.dataIDField;
            }
            set {
                this.dataIDField = value;
                this.RaisePropertyChanged("DataID");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public int Dimension {
            get {
                return this.dimensionField;
            }
            set {
                this.dimensionField = value;
                this.RaisePropertyChanged("Dimension");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public int CountAtoms {
            get {
                return this.countAtomsField;
            }
            set {
                this.countAtomsField = value;
                this.RaisePropertyChanged("CountAtoms");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=3)]
        public int CountDistinctAtoms {
            get {
                return this.countDistinctAtomsField;
            }
            set {
                this.countDistinctAtomsField = value;
                this.RaisePropertyChanged("CountDistinctAtoms");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=4)]
        public int CountBasisFunctions {
            get {
                return this.countBasisFunctionsField;
            }
            set {
                this.countBasisFunctionsField = value;
                this.RaisePropertyChanged("CountBasisFunctions");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=5)]
        public int CountBasisFunctionMonoms {
            get {
                return this.countBasisFunctionMonomsField;
            }
            set {
                this.countBasisFunctionMonomsField = value;
                this.RaisePropertyChanged("CountBasisFunctionMonoms");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=6)]
        public double MinXValue {
            get {
                return this.minXValueField;
            }
            set {
                this.minXValueField = value;
                this.RaisePropertyChanged("MinXValue");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=7)]
        public double MaxXValue {
            get {
                return this.maxXValueField;
            }
            set {
                this.maxXValueField = value;
                this.RaisePropertyChanged("MaxXValue");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=8)]
        public double MinYValue {
            get {
                return this.minYValueField;
            }
            set {
                this.minYValueField = value;
                this.RaisePropertyChanged("MinYValue");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=9)]
        public double MaxYValue {
            get {
                return this.maxYValueField;
            }
            set {
                this.maxYValueField = value;
                this.RaisePropertyChanged("MaxYValue");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=10)]
        public double MinZValue {
            get {
                return this.minZValueField;
            }
            set {
                this.minZValueField = value;
                this.RaisePropertyChanged("MinZValue");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=11)]
        public double MaxZValue {
            get {
                return this.maxZValueField;
            }
            set {
                this.maxZValueField = value;
                this.RaisePropertyChanged("MaxZValue");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("AtomsTable", Order=12)]
        public AtomIntAttribute[] AtomsTable {
            get {
                return this.atomsTableField;
            }
            set {
                this.atomsTableField = value;
                this.RaisePropertyChanged("AtomsTable");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=13)]
        public int ExitCode {
            get {
                return this.exitCodeField;
            }
            set {
                this.exitCodeField = value;
                this.RaisePropertyChanged("ExitCode");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class Package : object, System.ComponentModel.INotifyPropertyChanged {

        private string packageIdField;

        private string[] methodIdsField;

        private string[] basisIdsField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string packageId {
            get {
                return this.packageIdField;
            }
            set {
                this.packageIdField = value;
                this.RaisePropertyChanged("packageId");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("methodIds", Order=1)]
        public string[] methodIds {
            get {
                return this.methodIdsField;
            }
            set {
                this.methodIdsField = value;
                this.RaisePropertyChanged("methodIds");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("basisIds", Order=2)]
        public string[] basisIds {
            get {
                return this.basisIdsField;
            }
            set {
                this.basisIdsField = value;
                this.RaisePropertyChanged("basisIds");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class MetaData : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIDField;

        private string taskIDField;

        private string createdAtField;

        private string formatField;

        private string authorField;

        private string labelField;

        private string sourceField;

        private Attribute[] attributesField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataID {
            get {
                return this.dataIDField;
            }
            set {
                this.dataIDField = value;
                this.RaisePropertyChanged("DataID");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string TaskID {
            get {
                return this.taskIDField;
            }
            set {
                this.taskIDField = value;
                this.RaisePropertyChanged("TaskID");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public string CreatedAt {
            get {
                return this.createdAtField;
            }
            set {
                this.createdAtField = value;
                this.RaisePropertyChanged("CreatedAt");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=3)]
        public string Format {
            get {
                return this.formatField;
            }
            set {
                this.formatField = value;
                this.RaisePropertyChanged("Format");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=4)]
        public string Author {
            get {
                return this.authorField;
            }
            set {
                this.authorField = value;
                this.RaisePropertyChanged("Author");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=5)]
        public string Label {
            get {
                return this.labelField;
            }
            set {
                this.labelField = value;
                this.RaisePropertyChanged("Label");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(DataType="anyURI", Order=6)]
        public string Source {
            get {
                return this.sourceField;
            }
            set {
                this.sourceField = value;
                this.RaisePropertyChanged("Source");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("Attributes", Order=7)]
        public Attribute[] Attributes {
            get {
                return this.attributesField;
            }
            set {
                this.attributesField = value;
                this.RaisePropertyChanged("Attributes");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class Attribute : object, System.ComponentModel.INotifyPropertyChanged {

        private string keyField;

        private string valueField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string Key {
            get {
                return this.keyField;
            }
            set {
                this.keyField = value;
                this.RaisePropertyChanged("Key");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
                this.RaisePropertyChanged("Value");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class DataContent : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIDField;

        private string calcPackageField;

        private string calcMethodField;

        private byte[] contentField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataID {
            get {
                return this.dataIDField;
            }
            set {
                this.dataIDField = value;
                this.RaisePropertyChanged("DataID");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string CalcPackage {
            get {
                return this.calcPackageField;
            }
            set {
                this.calcPackageField = value;
                this.RaisePropertyChanged("CalcPackage");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public string CalcMethod {
            get {
                return this.calcMethodField;
            }
            set {
                this.calcMethodField = value;
                this.RaisePropertyChanged("CalcMethod");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(DataType="base64Binary", Order=3)]
        public byte[] Content {
            get {
                return this.contentField;
            }
            set {
                this.contentField = value;
                this.RaisePropertyChanged("Content");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class Atom : object, System.ComponentModel.INotifyPropertyChanged {

        private int elementField;

        private double xField;

        private double yField;

        private double zField;

        public Atom() {
            this.elementField = 6;
            this.xField = 0;
            this.yField = 0;
            this.zField = 0;
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public int element {
            get {
                return this.elementField;
            }
            set {
                this.elementField = value;
                this.RaisePropertyChanged("element");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        [System.ComponentModel.DefaultValueAttribute(0)]
        public double x {
            get {
                return this.xField;
            }
            set {
                this.xField = value;
                this.RaisePropertyChanged("x");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        [System.ComponentModel.DefaultValueAttribute(0)]
        public double y {
            get {
                return this.yField;
            }
            set {
                this.yField = value;
                this.RaisePropertyChanged("y");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=3)]
        [System.ComponentModel.DefaultValueAttribute(0)]
        public double z {
            get {
                return this.zField;
            }
            set {
                this.zField = value;
                this.RaisePropertyChanged("z");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class postDataResponse : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class postDataRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.postDataRequest postDataRequest;

        public postDataRequest1() {
        }

        public postDataRequest1(nvis_svc_http.StorageService.postDataRequest postDataRequest) {
            this.postDataRequest = postDataRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class postDataResponse1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.postDataResponse postDataResponse;

        public postDataResponse1() {
        }

        public postDataResponse1(nvis_svc_http.StorageService.postDataResponse postDataResponse) {
            this.postDataResponse = postDataResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        private string packageField;

        private string methodField;

        private MethodParam[] additionalParamsField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string package {
            get {
                return this.packageField;
            }
            set {
                this.packageField = value;
                this.RaisePropertyChanged("package");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public string method {
            get {
                return this.methodField;
            }
            set {
                this.methodField = value;
                this.RaisePropertyChanged("method");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("additionalParams", Order=3)]
        public MethodParam[] additionalParams {
            get {
                return this.additionalParamsField;
            }
            set {
                this.additionalParamsField = value;
                this.RaisePropertyChanged("additionalParams");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataResponse : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIDField;

        private string calcPackageField;

        private string calcMethodField;

        private MethodParam[] paramField;

        private Atom[] atomsField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataID {
            get {
                return this.dataIDField;
            }
            set {
                this.dataIDField = value;
                this.RaisePropertyChanged("DataID");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string CalcPackage {
            get {
                return this.calcPackageField;
            }
            set {
                this.calcPackageField = value;
                this.RaisePropertyChanged("CalcPackage");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public string CalcMethod {
            get {
                return this.calcMethodField;
            }
            set {
                this.calcMethodField = value;
                this.RaisePropertyChanged("CalcMethod");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("Param", Order=3)]
        public MethodParam[] Param {
            get {
                return this.paramField;
            }
            set {
                this.paramField = value;
                this.RaisePropertyChanged("Param");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("Atoms", Order=4)]
        public Atom[] Atoms {
            get {
                return this.atomsField;
            }
            set {
                this.atomsField = value;
                this.RaisePropertyChanged("Atoms");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataRequest getDataRequest;

        public getDataRequest1() {
        }

        public getDataRequest1(nvis_svc_http.StorageService.getDataRequest getDataRequest) {
            this.getDataRequest = getDataRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataResponse1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataResponse getDataResponse;

        public getDataResponse1() {
        }

        public getDataResponse1(nvis_svc_http.StorageService.getDataResponse getDataResponse) {
            this.getDataResponse = getDataResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataContentRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        private string packageField;

        private string methodField;

        private MethodParam[] additionalParamsField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=1)]
        public string package {
            get {
                return this.packageField;
            }
            set {
                this.packageField = value;
                this.RaisePropertyChanged("package");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public string method {
            get {
                return this.methodField;
            }
            set {
                this.methodField = value;
                this.RaisePropertyChanged("method");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("additionalParams", Order=3)]
        public MethodParam[] additionalParams {
            get {
                return this.additionalParamsField;
            }
            set {
                this.additionalParamsField = value;
                this.RaisePropertyChanged("additionalParams");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataContentResponse : object, System.ComponentModel.INotifyPropertyChanged {

        private DataContent contentField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public DataContent content {
            get {
                return this.contentField;
            }
            set {
                this.contentField = value;
                this.RaisePropertyChanged("content");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataContentRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataContentRequest getDataContentRequest;

        public getDataContentRequest1() {
        }

        public getDataContentRequest1(nvis_svc_http.StorageService.getDataContentRequest getDataContentRequest) {
            this.getDataContentRequest = getDataContentRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataContentResponse1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataContentResponse getDataContentResponse;

        public getDataContentResponse1() {
        }

        public getDataContentResponse1(nvis_svc_http.StorageService.getDataContentResponse getDataContentResponse) {
            this.getDataContentResponse = getDataContentResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class forwardDataRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        private string urlField;

        private string packageField;

        private string methodField;

        private MethodParam[] additionalParamsField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(DataType="anyURI", Order=1)]
        public string url {
            get {
                return this.urlField;
            }
            set {
                this.urlField = value;
                this.RaisePropertyChanged("url");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=2)]
        public string package {
            get {
                return this.packageField;
            }
            set {
                this.packageField = value;
                this.RaisePropertyChanged("package");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute(Order=3)]
        public string method {
            get {
                return this.methodField;
            }
            set {
                this.methodField = value;
                this.RaisePropertyChanged("method");
            }
        }

        [System.Xml.Serialization.XmlElementAttribute("additionalParams", Order=4)]
        public MethodParam[] additionalParams {
            get {
                return this.additionalParamsField;
            }
            set {
                this.additionalParamsField = value;
                this.RaisePropertyChanged("additionalParams");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class forwardDataResponse : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class forwardDataRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.forwardDataRequest forwardDataRequest;

        public forwardDataRequest1() {
        }

        public forwardDataRequest1(nvis_svc_http.StorageService.forwardDataRequest forwardDataRequest) {
            this.forwardDataRequest = forwardDataRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class forwardDataResponse1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.forwardDataResponse forwardDataResponse;

        public forwardDataResponse1() {
        }

        public forwardDataResponse1(nvis_svc_http.StorageService.forwardDataResponse forwardDataResponse) {
            this.forwardDataResponse = forwardDataResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getMetaDataRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getMetaDataResponse : object, System.ComponentModel.INotifyPropertyChanged {

        private MetaData metadataField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public MetaData metadata {
            get {
                return this.metadataField;
            }
            set {
                this.metadataField = value;
                this.RaisePropertyChanged("metadata");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getMetaDataRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getMetaDataRequest getMetaDataRequest;

        public getMetaDataRequest1() {
        }

        public getMetaDataRequest1(nvis_svc_http.StorageService.getMetaDataRequest getMetaDataRequest) {
            this.getMetaDataRequest = getMetaDataRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getMetaDataResponse1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getMetaDataResponse getMetaDataResponse;

        public getMetaDataResponse1() {
        }

        public getMetaDataResponse1(nvis_svc_http.StorageService.getMetaDataResponse getMetaDataResponse) {
            this.getMetaDataResponse = getMetaDataResponse;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class listPackagesRequest {

        public listPackagesRequest() {
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class listPackagesResponse {

        [System.ServiceModel.MessageBodyMemberAttribute(Name="listPackagesResponse", Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        [System.Xml.Serialization.XmlArrayItemAttribute("packages", IsNullable=false)]
        public Package[] listPackagesResponse1;

        public listPackagesResponse() {
        }

        public listPackagesResponse(Package[] listPackagesResponse1) {
            this.listPackagesResponse1 = listPackagesResponse1;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataCharacteristicsRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataCharacteristicsResponse : object, System.ComponentModel.INotifyPropertyChanged {

        private DataCharacteristics responseField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public DataCharacteristics response {
            get {
                return this.responseField;
            }
            set {
                this.responseField = value;
                this.RaisePropertyChanged("response");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataCharacteristicsRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataCharacteristicsRequest getDataCharacteristicsRequest;

        public getDataCharacteristicsRequest1() {
        }

        public getDataCharacteristicsRequest1(nvis_svc_http.StorageService.getDataCharacteristicsRequest getDataCharacteristicsRequest) {
            this.getDataCharacteristicsRequest = getDataCharacteristicsRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataCharacteristicsResponse1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataCharacteristicsResponse getDataCharacteristicsResponse;

        public getDataCharacteristicsResponse1() {
        }

        public getDataCharacteristicsResponse1(nvis_svc_http.StorageService.getDataCharacteristicsResponse getDataCharacteristicsResponse) {
            this.getDataCharacteristicsResponse = getDataCharacteristicsResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class listDataIdsByTaskIdRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string taskIdField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string TaskId {
            get {
                return this.taskIdField;
            }
            set {
                this.taskIdField = value;
                this.RaisePropertyChanged("TaskId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class listDataIdsByTaskIdRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.listDataIdsByTaskIdRequest listDataIdsByTaskIdRequest;

        public listDataIdsByTaskIdRequest1() {
        }

        public listDataIdsByTaskIdRequest1(nvis_svc_http.StorageService.listDataIdsByTaskIdRequest listDataIdsByTaskIdRequest) {
            this.listDataIdsByTaskIdRequest = listDataIdsByTaskIdRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class listDataIdsByTaskIdResponse {

        [System.ServiceModel.MessageBodyMemberAttribute(Name="listDataIdsByTaskIdResponse", Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        [System.Xml.Serialization.XmlArrayItemAttribute("metadata", IsNullable=false)]
        public MetaData[] listDataIdsByTaskIdResponse1;

        public listDataIdsByTaskIdResponse() {
        }

        public listDataIdsByTaskIdResponse(MetaData[] listDataIdsByTaskIdResponse1) {
            this.listDataIdsByTaskIdResponse1 = listDataIdsByTaskIdResponse1;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataLengthRequest : object, System.ComponentModel.INotifyPropertyChanged {

        private string dataIdField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public string DataId {
            get {
                return this.dataIdField;
            }
            set {
                this.dataIdField = value;
                this.RaisePropertyChanged("DataId");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="urn:ru:ifmo:nanoio:apiws:baseWS")]
    public partial class getDataLengthResponse : object, System.ComponentModel.INotifyPropertyChanged {

        private long lengthField;

        [System.Xml.Serialization.XmlElementAttribute(Order=0)]
        public long Length {
            get {
                return this.lengthField;
            }
            set {
                this.lengthField = value;
                this.RaisePropertyChanged("Length");
            }
        }

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName) {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null)) {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataLengthRequest1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataLengthRequest getDataLengthRequest;

        public getDataLengthRequest1() {
        }

        public getDataLengthRequest1(nvis_svc_http.StorageService.getDataLengthRequest getDataLengthRequest) {
            this.getDataLengthRequest = getDataLengthRequest;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    [System.ServiceModel.MessageContractAttribute(IsWrapped=false)]
    public partial class getDataLengthResponse1 {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace="urn:ru:ifmo:nanoio:apiws:baseWS", Order=0)]
        public nvis_svc_http.StorageService.getDataLengthResponse getDataLengthResponse;

        public getDataLengthResponse1() {
        }

        public getDataLengthResponse1(nvis_svc_http.StorageService.getDataLengthResponse getDataLengthResponse) {
            this.getDataLengthResponse = getDataLengthResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public interface NanoIOSystemAPIInterfaceChannel : nvis_svc_http.StorageService.NanoIOSystemAPIInterface, System.ServiceModel.IClientChannel {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
    public partial class NanoIOSystemAPIInterfaceClient : System.ServiceModel.ClientBase<nvis_svc_http.StorageService.NanoIOSystemAPIInterface>, nvis_svc_http.StorageService.NanoIOSystemAPIInterface {

        public NanoIOSystemAPIInterfaceClient() {
        }

        public NanoIOSystemAPIInterfaceClient(string endpointConfigurationName) :
                base(endpointConfigurationName) {
        }

        public NanoIOSystemAPIInterfaceClient(string endpointConfigurationName, string remoteAddress) :
                base(endpointConfigurationName, remoteAddress) {
        }

        public NanoIOSystemAPIInterfaceClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
                base(endpointConfigurationName, remoteAddress) {
        }

        public NanoIOSystemAPIInterfaceClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
                base(binding, remoteAddress) {
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.postDataResponse1 nvis_svc_http.StorageService.NanoIOSystemAPIInterface.postData(nvis_svc_http.StorageService.postDataRequest1 request) {
            return base.Channel.postData(request);
        }

        public nvis_svc_http.StorageService.postDataResponse postData(nvis_svc_http.StorageService.postDataRequest postDataRequest) {
            nvis_svc_http.StorageService.postDataRequest1 inValue = new nvis_svc_http.StorageService.postDataRequest1();
            inValue.postDataRequest = postDataRequest;
            nvis_svc_http.StorageService.postDataResponse1 retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).postData(inValue);
            return retVal.postDataResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.getDataResponse1 nvis_svc_http.StorageService.NanoIOSystemAPIInterface.getData(nvis_svc_http.StorageService.getDataRequest1 request) {
            return base.Channel.getData(request);
        }

        public nvis_svc_http.StorageService.getDataResponse getData(nvis_svc_http.StorageService.getDataRequest getDataRequest) {
            nvis_svc_http.StorageService.getDataRequest1 inValue = new nvis_svc_http.StorageService.getDataRequest1();
            inValue.getDataRequest = getDataRequest;
            nvis_svc_http.StorageService.getDataResponse1 retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).getData(inValue);
            return retVal.getDataResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.getDataContentResponse1 nvis_svc_http.StorageService.NanoIOSystemAPIInterface.getDataContent(nvis_svc_http.StorageService.getDataContentRequest1 request) {
            return base.Channel.getDataContent(request);
        }

        public nvis_svc_http.StorageService.getDataContentResponse getDataContent(nvis_svc_http.StorageService.getDataContentRequest getDataContentRequest) {
            nvis_svc_http.StorageService.getDataContentRequest1 inValue = new nvis_svc_http.StorageService.getDataContentRequest1();
            inValue.getDataContentRequest = getDataContentRequest;
            nvis_svc_http.StorageService.getDataContentResponse1 retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).getDataContent(inValue);
            return retVal.getDataContentResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.forwardDataResponse1 nvis_svc_http.StorageService.NanoIOSystemAPIInterface.forwardData(nvis_svc_http.StorageService.forwardDataRequest1 request) {
            return base.Channel.forwardData(request);
        }

        public nvis_svc_http.StorageService.forwardDataResponse forwardData(nvis_svc_http.StorageService.forwardDataRequest forwardDataRequest) {
            nvis_svc_http.StorageService.forwardDataRequest1 inValue = new nvis_svc_http.StorageService.forwardDataRequest1();
            inValue.forwardDataRequest = forwardDataRequest;
            nvis_svc_http.StorageService.forwardDataResponse1 retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).forwardData(inValue);
            return retVal.forwardDataResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.getMetaDataResponse1 nvis_svc_http.StorageService.NanoIOSystemAPIInterface.getMetaData(nvis_svc_http.StorageService.getMetaDataRequest1 request) {
            return base.Channel.getMetaData(request);
        }

        public nvis_svc_http.StorageService.getMetaDataResponse getMetaData(nvis_svc_http.StorageService.getMetaDataRequest getMetaDataRequest) {
            nvis_svc_http.StorageService.getMetaDataRequest1 inValue = new nvis_svc_http.StorageService.getMetaDataRequest1();
            inValue.getMetaDataRequest = getMetaDataRequest;
            nvis_svc_http.StorageService.getMetaDataResponse1 retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).getMetaData(inValue);
            return retVal.getMetaDataResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.listPackagesResponse nvis_svc_http.StorageService.NanoIOSystemAPIInterface.listPackages(nvis_svc_http.StorageService.listPackagesRequest request) {
            return base.Channel.listPackages(request);
        }

        public Package[] listPackages() {
            nvis_svc_http.StorageService.listPackagesRequest inValue = new nvis_svc_http.StorageService.listPackagesRequest();
            nvis_svc_http.StorageService.listPackagesResponse retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).listPackages(inValue);
            return retVal.listPackagesResponse1;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.getDataCharacteristicsResponse1 nvis_svc_http.StorageService.NanoIOSystemAPIInterface.getDataCharacteristics(nvis_svc_http.StorageService.getDataCharacteristicsRequest1 request) {
            return base.Channel.getDataCharacteristics(request);
        }

        public nvis_svc_http.StorageService.getDataCharacteristicsResponse getDataCharacteristics(nvis_svc_http.StorageService.getDataCharacteristicsRequest getDataCharacteristicsRequest) {
            nvis_svc_http.StorageService.getDataCharacteristicsRequest1 inValue = new nvis_svc_http.StorageService.getDataCharacteristicsRequest1();
            inValue.getDataCharacteristicsRequest = getDataCharacteristicsRequest;
            nvis_svc_http.StorageService.getDataCharacteristicsResponse1 retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).getDataCharacteristics(inValue);
            return retVal.getDataCharacteristicsResponse;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.listDataIdsByTaskIdResponse nvis_svc_http.StorageService.NanoIOSystemAPIInterface.listDataIdsByTaskId(nvis_svc_http.StorageService.listDataIdsByTaskIdRequest1 request) {
            return base.Channel.listDataIdsByTaskId(request);
        }

        public MetaData[] listDataIdsByTaskId(nvis_svc_http.StorageService.listDataIdsByTaskIdRequest listDataIdsByTaskIdRequest) {
            nvis_svc_http.StorageService.listDataIdsByTaskIdRequest1 inValue = new nvis_svc_http.StorageService.listDataIdsByTaskIdRequest1();
            inValue.listDataIdsByTaskIdRequest = listDataIdsByTaskIdRequest;
            nvis_svc_http.StorageService.listDataIdsByTaskIdResponse retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).listDataIdsByTaskId(inValue);
            return retVal.listDataIdsByTaskIdResponse1;
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        nvis_svc_http.StorageService.getDataLengthResponse1 nvis_svc_http.StorageService.NanoIOSystemAPIInterface.getDataLength(nvis_svc_http.StorageService.getDataLengthRequest1 request) {
            return base.Channel.getDataLength(request);
        }

        public nvis_svc_http.StorageService.getDataLengthResponse getDataLength(nvis_svc_http.StorageService.getDataLengthRequest getDataLengthRequest) {
            nvis_svc_http.StorageService.getDataLengthRequest1 inValue = new nvis_svc_http.StorageService.getDataLengthRequest1();
            inValue.getDataLengthRequest = getDataLengthRequest;
            nvis_svc_http.StorageService.getDataLengthResponse1 retVal = ((nvis_svc_http.StorageService.NanoIOSystemAPIInterface)(this)).getDataLength(inValue);
            return retVal.getDataLengthResponse;
        }
    }
}
