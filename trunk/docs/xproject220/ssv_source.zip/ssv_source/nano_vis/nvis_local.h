

#pragma once

#include "../core/core.h"

#ifdef _DEBUG
#    define D3D_DEBUG_INFO
#endif

#define D3D_DEBUG_INFO

#include <d3d9.h>
#include <d3dx9.h>

#define    WIN32_LEAN_AND_MEAN
#define    VC_EXTRALEAN
#include <windows.h>

#pragma comment (lib, "d3dxof.lib")
#pragma comment (lib, "dxguid.lib")
#pragma comment (lib, "d3dx9.lib")
#pragma comment (lib, "d3d9.lib")
#pragma comment (lib, "winmm.lib")

#define CHECK_CRITICAL(expr) if (FAILED(expr)) { SYS_Error(ERR_FATAL, va("%s() : %s failed", __FUNCTION__, #expr)); }

#define SAFE_RELEASE(obj) if (obj) { obj->Release(); obj = NULL; }

#include "openbabel/mol.h"
#include "openbabel/obconversion.h"
#include "openbabel/griddata.h"

#include "nvis.h"
